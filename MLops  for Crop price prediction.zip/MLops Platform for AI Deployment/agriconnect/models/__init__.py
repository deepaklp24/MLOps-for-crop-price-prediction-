from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

# Import models to make them available
from .user import User
from .farmer import Farmer
from .product import Product
from .order import Order
from .market_price import MarketPrice
from .prediction import PricePrediction
from .admin_log import AdminLog

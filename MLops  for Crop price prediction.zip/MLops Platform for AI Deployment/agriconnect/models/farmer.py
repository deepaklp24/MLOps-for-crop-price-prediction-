from . import db

class Farmer(db.Model):
    __tablename__ = 'farmers'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, unique=True)
    farm_name = db.Column(db.String(100), nullable=False)
    location_lat = db.Column(db.Float, nullable=True)
    location_lng = db.Column(db.Float, nullable=True)
    farm_size_acres = db.Column(db.Float, nullable=False)
    address = db.Column(db.Text, nullable=False)
    state = db.Column(db.String(50), nullable=False)
    district = db.Column(db.String(50), nullable=False)
    land_document_url = db.Column(db.String(255), nullable=True)

    # Relationships
    products = db.relationship('Product', backref='farmer', lazy=True, cascade="all, delete-orphan")

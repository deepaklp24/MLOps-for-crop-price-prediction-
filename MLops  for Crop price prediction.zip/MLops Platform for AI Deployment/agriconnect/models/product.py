from datetime import datetime, timezone
from . import db

class Product(db.Model):
    __tablename__ = 'products'
    
    id = db.Column(db.Integer, primary_key=True)
    farmer_id = db.Column(db.Integer, db.ForeignKey('farmers.id', ondelete='CASCADE'), nullable=False)
    crop_name = db.Column(db.String(50), nullable=False)
    category = db.Column(db.String(20), nullable=False)  # 'vegetables', 'fruits', 'grains', 'pulses'
    quantity_kg = db.Column(db.Float, nullable=False)
    price_per_kg = db.Column(db.Float, nullable=False)
    description = db.Column(db.Text, nullable=True)
    photo_url = db.Column(db.String(255), nullable=True)
    status = db.Column(db.String(15), default='available')  # 'available', 'sold', 'hidden'
    harvest_date = db.Column(db.Date, nullable=False)
    listed_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    location_lat = db.Column(db.Float, nullable=True)
    location_lng = db.Column(db.Float, nullable=True)

    # Relationships
    orders = db.relationship('Order', backref='product', lazy=True, cascade="all, delete-orphan")

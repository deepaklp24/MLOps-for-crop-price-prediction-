from datetime import datetime, timezone
from . import db

class PricePrediction(db.Model):
    __tablename__ = 'price_predictions'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='SET NULL'), nullable=True)
    crop_name = db.Column(db.String(50), nullable=False)
    predicted_price = db.Column(db.Float, nullable=False)
    prediction_date = db.Column(db.Date, nullable=False)
    confidence_score = db.Column(db.Float, nullable=False)
    model_version = db.Column(db.String(20), default='1.0.0')
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))

    # Relationships
    user = db.relationship('User', backref='predictions')

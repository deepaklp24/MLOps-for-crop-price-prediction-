from datetime import datetime, timezone
import bcrypt
from flask_login import UserMixin
from . import db

class User(db.Model, UserMixin):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    role = db.Column(db.String(10), nullable=False)  # 'farmer', 'buyer', 'admin'
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    is_verified = db.Column(db.Boolean, default=False)
    
    # Lockout security fields
    failed_login_attempts = db.Column(db.Integer, default=0)
    lockout_until = db.Column(db.DateTime, nullable=True)

    # Relationships
    farmer_profile = db.relationship('Farmer', backref='user', uselist=False, cascade="all, delete-orphan")
    orders = db.relationship('Order', backref='buyer', lazy=True)
    logs = db.relationship('AdminLog', backref='admin_user', lazy=True)

    def set_password(self, password):
        salt = bcrypt.gensalt()
        self.password_hash = bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')

    def check_password(self, password):
        if not self.password_hash:
            return False
        try:
            return bcrypt.checkpw(password.encode('utf-8'), self.password_hash.encode('utf-8'))
        except Exception:
            return False

    def is_locked_out(self):
        if self.lockout_until:
            if datetime.now(timezone.utc) < self.lockout_until.replace(tzinfo=timezone.utc) if self.lockout_until.tzinfo is None else self.lockout_until:
                return True
            else:
                # Lockout expired, reset attempts
                self.lockout_until = None
                self.failed_login_attempts = 0
                db.session.commit()
        return False

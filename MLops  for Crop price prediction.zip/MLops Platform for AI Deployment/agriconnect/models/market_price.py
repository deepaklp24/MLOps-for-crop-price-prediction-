from datetime import date
from . import db

class MarketPrice(db.Model):
    __tablename__ = 'market_prices'
    
    id = db.Column(db.Integer, primary_key=True)
    crop_name = db.Column(db.String(50), nullable=False)
    state = db.Column(db.String(50), nullable=False)
    price_per_quintal = db.Column(db.Float, nullable=False)
    price_date = db.Column(db.Date, default=date.today)
    source = db.Column(db.String(100), default='Government Market Feed')

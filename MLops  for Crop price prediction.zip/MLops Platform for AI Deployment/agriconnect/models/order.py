from datetime import datetime, timezone
from . import db

class Order(db.Model):
    __tablename__ = 'orders'
    
    id = db.Column(db.Integer, primary_key=True)
    buyer_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id', ondelete='CASCADE'), nullable=False)
    quantity_kg = db.Column(db.Float, nullable=False)
    total_price = db.Column(db.Float, nullable=False)
    order_status = db.Column(db.String(20), default='pending')  # 'pending', 'confirmed', 'delivered'
    order_date = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    delivery_address = db.Column(db.Text, nullable=False)

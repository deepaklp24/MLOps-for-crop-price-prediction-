# AgriConnect

**AI-Powered Agricultural Price Predictor & Direct Farm-to-Buyer Marketplace**  
*An MLOps-enabled Capstone Project for MCA Submission.*

---

## 📖 Project Abstract
Smallholder farmers in developing regions (such as India) frequently experience financial exploitation due to asymmetrical market information and reliance on intermediary agents (middlemen). AgriConnect addresses this systemic issue by providing:
1. **Direct Digital Marketplace**: Connecting farmers directly to food processors, retail buyers, and warehouses.
2. **AI-driven Sourcing Recommendations**: Utilizing scikit-learn Machine Learning models trained on state-level climatic and demand indices to predict fair pricing bands.
3. **Transparent Logistics**: Visualizing farm coordinates and buyer orders on an interactive Leaflet.js map.

This project implements a complete Flask MVC backend, SQLite database schema via SQLAlchemy, and a RandomForestRegressor predictor pipeline to achieve these capabilities.

---

## 🏗️ System Architecture
```mermaid
graph TD
    User[Web Browser] <-->|HTTPS / HTML5 / JS| Flask[Flask Web Application]
    Flask <-->|ORM queries| SQLite[(SQLite Database)]
    Flask <-->|Joblib / inference| ML[Trained RandomForest Model]
    Flask <-->|reverse-geocoding| OSM[OpenStreetMap Nominatim API]
    User <-->|tile rendering| Leaflet[Leaflet.js Map CDN]
```

---

## 📊 Entity-Relationship (ER) Diagram
```mermaid
erDiagram
    USERS ||--|| FARMERS : "extends"
    USERS ||--o{ ORDERS : "places (buyer)"
    FARMERS ||--o{ PRODUCTS : "lists"
    PRODUCTS ||--o{ ORDERS : "contains"
    USERS ||--o{ PRICE_PREDICTIONS : "audits"
    USERS ||--o{ ADMIN_LOGS : "logs (admin)"

    USERS {
        int id PK
        string full_name
        string email UK
        string password_hash
        string phone
        string role
        datetime created_at
        boolean is_verified
    }
    FARMERS {
        int id PK
        int user_id FK
        string farm_name
        float location_lat
        float location_lng
        float farm_size_acres
        text address
        string state
        string district
    }
    PRODUCTS {
        int id PK
        int farmer_id FK
        string crop_name
        string category
        float quantity_kg
        float price_per_kg
        text description
        string photo_url
        string status
        date harvest_date
        datetime listed_at
        float location_lat
        float location_lng
    }
    ORDERS {
        int id PK
        int buyer_id FK
        int product_id FK
        float quantity_kg
        float total_price
        string order_status
        datetime order_date
        text delivery_address
    }
    MARKET_PRICE {
        int id PK
        string crop_name
        string state
        float price_per_quintal
        date price_date
        string source
    }
    PRICE_PREDICTIONS {
        int id PK
        int user_id FK
        string crop_name
        float predicted_price
        date prediction_date
        float confidence_score
        string model_version
        datetime created_at
    }
    ADMIN_LOGS {
        int id PK
        int admin_id FK
        string action
        string target_table
        int target_id
        datetime timestamp
    }
```

---

## 🧠 Machine Learning Model Evaluation
The crop price prediction is powered by a **RandomForestRegressor** model.

### Features Utilized:
*   `crop_name_encoded` (Label Encoded, 30+ crops)
*   `state_encoded` (Label Encoded, 20 States)
*   `month` (1-12)
*   `season` (0=Kharif, 1=Rabi, 2=Zaid)
*   `year` (2020-2026)
*   `rainfall_index` (Climatic supply indicator, 0.0 - 1.0)
*   `demand_score` (Market demand indicator, 0.0 - 1.0)
*   `historical_avg_price` (Rolling baseline price, INR)

### Evaluation Metrics (Evaluated on a 20% hold-out test set):
*   **R² Accuracy Score**: `0.9927` (Highly accurate fit on synthetic agricultural variations)
*   **Mean Absolute Error (MAE)**: `INR 205.58 per quintal` (approx. `₹2.05 per kg` deviation)
*   **Root Mean Squared Error (RMSE)**: `INR 300.75 per quintal` (approx. `₹3.00 per kg` deviation)

*Confidence Interval*: Calculated on inference using individual decision tree predictions:
$$\text{Confidence Score} = 1 - \frac{\sigma(\text{Tree Predictions})}{\mu(\text{Tree Predictions})}$$

---

## ⚙️ Project Setup Instructions

### 1. Prerequisites
Ensure you have **Python 3.11+** installed on your machine.

### 2. Installation
Open your terminal in the workspace root folder and follow these commands:

```bash
# Navigate to project directory
cd agriconnect

# Install dependencies
pip install -r requirements.txt
```

### 3. Initialize ML Model & Database Seeding
Run the following scripts in order to train the ML model and seed the SQLite tables:

```bash
# 1. Train and save RandomForest model
python ml/train_model.py

# 2. Seed database with Admin, Farmers, Buyers, and Crops
python database/seed_data.py
```

### 4. Running the Application
Start the Flask local development server:

```bash
python app.py
```
Open your browser and navigate to: **`http://127.0.0.1:5000`**

---

## 🔑 Default Seed Account Credentials
For testing role-based features, log in using the following accounts:

1.  **Administrator Panel**:
    *   **Email**: `admin@agriconnect.com`
    *   **Password**: `Admin@123`
2.  **Farmer Dashboard**:
    *   **Email**: `farmer1@agriconnect.com`
    *   **Password**: `Farmer@123`
3.  **Buyer Marketplace**:
    *   **Email**: `buyer1@agriconnect.com`
    *   **Password**: `Buyer@123`

---

## 📈 Conclusion & Future Scope
AgriConnect demonstrates the capability of integrating modern MLOps pipelines with transactional e-commerce marketplaces to solve real-world agricultural problems. 

By utilizing tree-based regression algorithms, we provide robust price forecasts that protect farmers from undervalued sales. In future expansions, this system could be integrated with:
*   Real-time satellite soil moisture indicators.
*   Government APMC APIs for actual real-time pricing feeds.
*   Secure blockchain-based escrow smart contracts to guarantee payments before crop transit.

// Universal helper scripts

document.addEventListener('DOMContentLoaded', () => {
    // Automatically close alert banners after 5 seconds
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.transition = 'opacity 0.5s ease-out';
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500);
        }, 5000);
    });
});

// Premium Toast Notification System
function showToast(message, type = 'info') {
    let toastContainer = document.querySelector('.toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.className = 'toast-container';
        toastContainer.style.cssText = 'position: fixed; bottom: 20px; right: 20px; z-index: 9999; display: flex; flex-direction: column; gap: 10px;';
        document.body.appendChild(toastContainer);
    }
    
    const toast = document.createElement('div');
    toast.className = `alert alert-${type}`;
    toast.style.cssText = 'margin-bottom: 0; min-width: 250px; box-shadow: 0 4px 15px rgba(0,0,0,0.15); animation: slideIn 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);';
    
    const colors = {
        success: '#2E7D32',
        danger: '#C62828',
        warning: '#F9A825',
        info: '#5D4037'
    };
    
    toast.innerHTML = `
        <div style="display:flex; align-items:center; gap: 10px;">
            <span style="font-weight:600; color: ${colors[type] || '#333'}">${message}</span>
        </div>
        <button onclick="this.parentElement.remove()" style="background:none; border:none; color:#999; font-size:1.2rem; cursor:pointer; margin-left: 15px;">&times;</button>
    `;
    
    toastContainer.appendChild(toast);
    
    setTimeout(() => {
        toast.style.transition = 'opacity 0.5s ease-out, transform 0.5s';
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(20px)';
        setTimeout(() => toast.remove(), 500);
    }, 4000);
}

// Client-side Password Strength Check
function checkPasswordStrength(password) {
    let score = 0;
    if (!password) return score;
    
    if (password.length >= 8) score++;
    if (/[a-z]/.test(password)) score++;
    if (/[A-Z]/.test(password)) score++;
    if (/[0-9]/.test(password)) score++;
    if (/[_@$!%*#?&]/.test(password)) score++;
    
    return score; // 0 to 5
}

// Client-side Price Prediction scripts

document.addEventListener('DOMContentLoaded', () => {
    const predictForm = document.getElementById('predict-form');
    const targetDateInput = document.getElementById('target_date');
    const seasonSelect = document.getElementById('season');
    
    // Auto-fill season from month selection
    if (targetDateInput && seasonSelect) {
        targetDateInput.addEventListener('change', () => {
            const dateVal = targetDateInput.value;
            if (!dateVal) return;
            
            const dateObj = new Date(dateVal);
            const month = dateObj.getMonth() + 1; // 1-12
            
            // 0=Kharif (June - October), 1=Rabi (November - April), 2=Zaid (March - June)
            // Note: March-June overlap, but let's align:
            // June-Oct: Kharif
            // Nov-Feb: Rabi
            // March-May: Zaid
            if (month >= 6 && month <= 10) {
                seasonSelect.value = 'Kharif';
            } else if (month >= 11 || month <= 2) {
                seasonSelect.value = 'Rabi';
            } else {
                seasonSelect.value = 'Zaid';
            }
        });
    }

    if (predictForm) {
        predictForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            // Show loading state
            const submitBtn = predictForm.querySelector('button[type="submit"]');
            const originalBtnText = submitBtn.innerHTML;
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<span style="display:inline-block; animation: spin 1s infinite linear; border: 2px solid #fff; border-top-color: transparent; border-radius: 50%; width: 14px; height: 14px; margin-right: 5px;"></span> Predicting...';
            
            // Collect form fields
            const payload = {
                crop_name: document.getElementById('crop_name').value,
                state: document.getElementById('state').value,
                target_date: document.getElementById('target_date').value,
                season: document.getElementById('season').value,
                quantity_kg: document.getElementById('quantity_kg').value
            };
            
            // Get CSRF Token
            const csrfToken = document.querySelector('input[name="csrf_token"]').value;
            
            try {
                const response = await fetch('/api/predict/price', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-Token': csrfToken
                    },
                    body: JSON.stringify(payload)
                });
                
                const data = await response.json();
                
                if (data.success) {
                    // Update Right Panel UI
                    document.getElementById('results-placeholder').style.display = 'none';
                    const resultsSection = document.getElementById('prediction-results-box');
                    resultsSection.style.display = 'block';
                    
                    // Fill predicted data
                    document.getElementById('res-crop-state').textContent = `${data.prediction.crop_name} in ${data.prediction.state}`;
                    document.getElementById('res-price').textContent = `₹${data.prediction.price_per_kg.toFixed(2)}`;
                    document.getElementById('res-confidence').textContent = `${data.prediction.confidence}%`;
                    document.getElementById('res-range').textContent = `₹${data.prediction.min_price.toFixed(2)} – ₹${data.prediction.max_price.toFixed(2)}`;
                    
                    const revBox = document.getElementById('res-revenue-box');
                    if (data.prediction.estimated_revenue > 0) {
                        revBox.style.display = 'block';
                        document.getElementById('res-revenue').textContent = `₹${data.prediction.estimated_revenue.toLocaleString('en-IN')}`;
                    } else {
                        revBox.style.display = 'none';
                    }
                    
                    // Recommendation badge coloring
                    const badge = document.getElementById('res-badge');
                    badge.textContent = data.prediction.recommendation;
                    
                    badge.className = 'badge'; // Reset
                    const rec = data.prediction.recommendation.toLowerCase();
                    if (rec.includes('good') || rec.includes('high')) {
                        badge.classList.add('badge-confirmed');
                    } else if (rec.includes('drop') || rec.includes('sell now')) {
                        badge.classList.add('badge-hidden');
                    } else {
                        badge.classList.add('badge-pending');
                    }
                    
                    // Render 30-day forecast trend chart
                    if (data.forecast && data.forecast.length > 0) {
                        renderForecastChart('forecast-chart', data.forecast);
                    }
                    
                    showToast('Prediction loaded successfully!', 'success');
                } else {
                    showToast(data.message || 'Prediction failed.', 'danger');
                }
            } catch (err) {
                console.error(err);
                showToast('Network error while predicting price.', 'danger');
            } finally {
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalBtnText;
            }
        });
    }
});

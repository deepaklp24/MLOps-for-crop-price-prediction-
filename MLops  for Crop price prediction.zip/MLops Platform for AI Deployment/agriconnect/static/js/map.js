// Leaflet.js Map Helpers for AgriConnect

let _mapInstance = null;
let _markerInstance = null;

// Custom Marker Icons
function getMarkerIcon(color) {
    let iconUrl = 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-green.png';
    if (color === 'blue') {
        iconUrl = 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-blue.png';
    } else if (color === 'red') {
        iconUrl = 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png';
    }
    
    return new L.Icon({
        iconUrl: iconUrl,
        shadowUrl: 'https://cdnjs.github.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
        iconSize: [25, 41],
        iconAnchor: [12, 41],
        popupAnchor: [1, -34],
        shadowSize: [41, 41]
    });
}

// 1. Initialise Land Location Map for Farmer View (shows land + nearby buyers)
function initFarmerMap(containerId, farmerLat, farmerLng, buyersCoords = []) {
    const defaultLat = farmerLat || 20.5937; // India center
    const defaultLng = farmerLng || 78.9629;
    const zoomLevel = farmerLat ? 11 : 5;
    
    const map = L.map(containerId).setView([defaultLat, defaultLng], zoomLevel);
    
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);
    
    // Add Farmer Marker
    if (farmerLat && farmerLng) {
        L.marker([farmerLat, farmerLng], { icon: getMarkerIcon('green') })
            .addTo(map)
            .bindPopup("<b>My Farm Location</b><br>Registered land coordinates.")
            .openPopup();
    }
    
    // Add Buyer Markers
    buyersCoords.forEach(b => {
        if (b.lat && b.lng) {
            L.marker([b.lat, b.lng], { icon: getMarkerIcon('blue') })
                .addTo(map)
                .bindPopup(`<b>Buyer: ${b.name}</b><br>Ordered: ${b.qty}kg of ${b.crop}`);
        }
    });
    
    return map;
}

// 2. Initialise static mini map for Product Detail modal
function initMiniProductMap(containerId, lat, lng, cropName, farmName) {
    if (!lat || !lng) return null;
    
    // Clear previous map if exists
    const container = document.getElementById(containerId);
    if (container._leaflet_id) {
        container.outerHTML = `<div id="${containerId}" style="height: 200px; border-radius: 8px;"></div>`;
    }
    
    setTimeout(() => {
        const map = L.map(containerId).setView([lat, lng], 12);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap contributors'
        }).addTo(map);
        
        L.marker([lat, lng], { icon: getMarkerIcon('green') })
            .addTo(map)
            .bindPopup(`<b>${cropName}</b><br>Farm: ${farmName}`)
            .openPopup();
    }, 100);
}

// 3. Geolocation & Reverse Geocoding via Nominatim (Free)
async function reverseGeocode(lat, lng) {
    try {
        const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1`, {
            headers: { 'User-Agent': 'AgriConnect/1.0' }
        });
        const data = await response.json();
        return {
            address: data.display_name,
            state: data.address.state || data.address.region || "",
            district: data.address.district || data.address.county || data.address.city || ""
        };
    } catch (error) {
        console.error("Geocoding lookup failed:", error);
        return null;
    }
}

// 4. Initialise Location Selector (Click to pick coordinates on register/product add forms)
function initLocationPicker(containerId, latInputId, lngInputId, addressInputId, stateInputId, districtInputId) {
    const latInput = document.getElementById(latInputId);
    const lngInput = document.getElementById(lngInputId);
    const addressInput = document.getElementById(addressInputId);
    const stateInput = document.getElementById(stateInputId);
    const districtInput = document.getElementById(districtInputId);
    
    const defaultLat = 20.5937;
    const defaultLng = 78.9629;
    
    _mapInstance = L.map(containerId).setView([defaultLat, defaultLng], 5);
    
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
    }).addTo(_mapInstance);
    
    // Check if browser geolocation available
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            async (position) => {
                const lat = position.coords.latitude;
                const lng = position.coords.longitude;
                updateMarker(lat, lng);
                _mapInstance.setView([lat, lng], 13);
                
                const geoData = await reverseGeocode(lat, lng);
                if (geoData) {
                    fillFormLocation(lat, lng, geoData);
                }
            },
            (error) => {
                console.warn("Geolocation permission denied/timeout. Using default center.");
            }
        );
    }
    
    _mapInstance.on('click', async (e) => {
        const lat = e.latlng.lat;
        const lng = e.latlng.lng;
        updateMarker(lat, lng);
        
        const geoData = await reverseGeocode(lat, lng);
        if (geoData) {
            fillFormLocation(lat, lng, geoData);
        } else {
            fillFormLocation(lat, lng, { address: `${lat.toFixed(4)}, ${lng.toFixed(4)}`, state: "", district: "" });
        }
    });
    
    function updateMarker(lat, lng) {
        if (_markerInstance) {
            _markerInstance.setLatLng([lat, lng]);
        } else {
            _markerInstance = L.marker([lat, lng], { icon: getMarkerIcon('green'), draggable: true }).addTo(_mapInstance);
            
            _markerInstance.on('dragend', async (event) => {
                const marker = event.target;
                const position = marker.getLatLng();
                const geoData = await reverseGeocode(position.lat, position.lng);
                if (geoData) {
                    fillFormLocation(position.lat, position.lng, geoData);
                }
            });
        }
    }
    
    function fillFormLocation(lat, lng, data) {
        if (latInput) latInput.value = lat;
        if (lngInput) lngInput.value = lng;
        if (addressInput) addressInput.value = data.address;
        if (stateInput) stateInput.value = data.state;
        if (districtInput) districtInput.value = data.district;
    }
}

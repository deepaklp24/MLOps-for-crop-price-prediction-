// Chart.js helper functions for AgriConnect

// 1. Render Price Trend Mini Line Chart (Farmer Dashboard)
function renderTrendChart(canvasId, labels, values, cropName) {
    const ctx = document.getElementById(canvasId).getContext('2d');
    
    // Clear existing chart if any
    const chartExist = Chart.getChart(canvasId);
    if (chartExist) chartExist.destroy();
    
    return new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: `${cropName} (Rs. per kg)`,
                data: values,
                borderColor: '#2E7D32',
                backgroundColor: 'rgba(46, 125, 50, 0.05)',
                borderWidth: 2.5,
                fill: true,
                tension: 0.3,
                pointBackgroundColor: '#2E7D32'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: {
                    grid: { color: 'rgba(0,0,0,0.05)' },
                    ticks: { font: { family: 'DM Mono' } }
                },
                x: {
                    grid: { display: false }
                }
            }
        }
    });
}

// 2. Render 30-Day Forecast Chart with Confidence Band (Prediction Page)
function renderForecastChart(canvasId, forecastData) {
    const ctx = document.getElementById(canvasId).getContext('2d');
    
    const chartExist = Chart.getChart(canvasId);
    if (chartExist) chartExist.destroy();
    
    const labels = forecastData.map(d => d.date);
    const prices = forecastData.map(d => d.price);
    const minPrices = forecastData.map(d => d.min_price);
    const maxPrices = forecastData.map(d => d.max_price);
    
    return new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Predicted Price',
                    data: prices,
                    borderColor: '#2E7D32',
                    backgroundColor: 'rgba(46, 125, 50, 0.1)',
                    borderWidth: 3,
                    fill: false,
                    tension: 0.2,
                    zIndex: 10
                },
                {
                    label: 'Max Price Band',
                    data: maxPrices,
                    borderColor: 'rgba(102, 187, 106, 0.3)',
                    backgroundColor: 'rgba(102, 187, 106, 0.1)',
                    borderWidth: 1,
                    pointRadius: 0,
                    fill: '+1', // Fill down to min price band (if supported)
                    borderDash: [5, 5]
                },
                {
                    label: 'Min Price Band',
                    data: minPrices,
                    borderColor: 'rgba(102, 187, 106, 0.3)',
                    backgroundColor: 'transparent',
                    borderWidth: 1,
                    pointRadius: 0,
                    fill: false,
                    borderDash: [5, 5]
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: {
                        filter: function(item, chart) {
                            // Only show Predicted Price in legend
                            return item.text === 'Predicted Price';
                        }
                    }
                }
            },
            scales: {
                y: {
                    grid: { color: 'rgba(0,0,0,0.05)' },
                    ticks: { font: { family: 'DM Mono' } }
                },
                x: {
                    grid: { display: false }
                }
            }
        }
    });
}

// 3. Render Admin Registration Bar Chart
function renderBarChart(canvasId, labels, data) {
    const ctx = document.getElementById(canvasId).getContext('2d');
    
    const chartExist = Chart.getChart(canvasId);
    if (chartExist) chartExist.destroy();
    
    return new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'New Registrations',
                data: data,
                backgroundColor: '#5D4037',
                borderRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: { grid: { color: 'rgba(0,0,0,0.05)' } },
                x: { grid: { display: false } }
            }
        }
    });
}

// 4. Render Admin Pie Chart
function renderPieChart(canvasId, labels, data) {
    const ctx = document.getElementById(canvasId).getContext('2d');
    
    const chartExist = Chart.getChart(canvasId);
    if (chartExist) chartExist.destroy();
    
    return new Chart(ctx, {
        type: 'pie',
        data: {
            labels: labels,
            datasets: [{
                data: data,
                backgroundColor: [
                    '#2E7D32', // grains (green)
                    '#5D4037', // pulses (brown)
                    '#F9A825', // vegetables (amber)
                    '#66BB6A'  // fruits (light green)
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false
        }
    });
}

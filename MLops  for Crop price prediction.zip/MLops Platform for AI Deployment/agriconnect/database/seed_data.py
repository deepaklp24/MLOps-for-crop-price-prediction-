import os
import sys
import random
from datetime import datetime, timedelta, date, timezone

# Add the parent directory to python path so we can import app and models
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app import create_app
from models import db, User, Farmer, Product, Order, MarketPrice, PricePrediction, AdminLog

def seed_database():
    app = create_app()
    with app.app_context():
        print("Re-creating database schema...")
        db.drop_all()
        db.create_all()

        # 1. Create Admin User
        admin = User(
            full_name="AgriConnect Administrator",
            email="admin@agriconnect.com",
            phone="9876543210",
            role="admin",
            is_verified=True
        )
        admin.set_password("Admin@123")
        db.session.add(admin)
        print("Admin user created.")

        # 2. Create Farmer Accounts
        # 10 Farmers in different states
        farmer_states = [
            ("Rajesh Kumar", "UP Farms", "Uttar Pradesh", "Meerut", 29.02, 77.70, 5.5),
            ("Satnam Singh", "Punjab Green Fields", "Punjab", "Ludhiana", 30.90, 75.85, 12.0),
            ("Ramesh Patel", "Gujarat Cotton Farms", "Gujarat", "Rajkot", 22.30, 70.80, 8.5),
            ("Shivaji Rao", "Maharashtra Agri Co", "Maharashtra", "Nashik", 19.99, 73.78, 6.0),
            ("Venkat Reddy", "Andhra Paddy Land", "Andhra Pradesh", "Guntur", 16.30, 80.45, 10.0),
            ("Madan Mohan", "MP Soybean Fields", "Madhya Pradesh", "Indore", 22.71, 75.85, 15.0),
            ("Sanjay Chaudhary", "Rajasthan Mustard Hub", "Rajasthan", "Alwar", 27.56, 76.60, 4.0),
            ("Amit Sarkar", "Bengal Rice Fields", "West Bengal", "Burdwan", 23.23, 87.86, 7.5),
            ("Kumaraswamy", "Karnataka Fruits & Spices", "Karnataka", "Chikmagalur", 13.31, 75.77, 9.0),
            ("Narasimhan", "Tamil Nadu Paddy & Coconut", "Tamil Nadu", "Thanjavur", 10.78, 79.13, 11.5)
        ]
        
        farmers = []
        for i, (name, farm, state, district, lat, lng, size) in enumerate(farmer_states):
            email = f"farmer{i+1}@agriconnect.com"
            user = User(
                full_name=name,
                email=email,
                phone=f"94400000{i:02d}",
                role="farmer",
                is_verified=True
            )
            user.set_password("Farmer@123")
            db.session.add(user)
            db.session.flush() # gets user.id
            
            farmer = Farmer(
                user_id=user.id,
                farm_name=farm,
                location_lat=lat,
                location_lng=lng,
                farm_size_acres=size,
                address=f"{farm}, Near Main Road, {district}, {state}",
                state=state,
                district=district,
                land_document_url=f"/static/uploads/land_doc_farmer{i+1}.pdf"
            )
            db.session.add(farmer)
            farmers.append(farmer)
            
        print("10 Farmer accounts seeded.")

        # 3. Create Buyer Accounts
        buyer_names = [
            "Kishore Agrowells",
            "BigBasket Local Sourcing",
            "GreenGrocers Pvt Ltd",
            "Suresh Agro Traders",
            "Radha Retail Stores"
        ]
        buyers = []
        for i, name in enumerate(buyer_names):
            email = f"buyer{i+1}@agriconnect.com"
            user = User(
                full_name=name,
                email=email,
                phone=f"98660000{i:02d}",
                role="buyer",
                is_verified=True
            )
            user.set_password("Buyer@123")
            db.session.add(user)
            buyers.append(user)
        print("5 Buyer accounts seeded.")
        db.session.flush()

        # 4. Create Product Listings (40 listings)
        crops = [
            ("Wheat", "grains", 20.0, 28.0),
            ("Paddy", "grains", 21.0, 30.0),
            ("Maize", "grains", 19.0, 26.0),
            ("Barley", "grains", 17.0, 24.0),
            ("Millet", "grains", 23.0, 32.0),
            ("Chickpeas", "pulses", 52.0, 65.0),
            ("Pigeon Peas", "pulses", 68.0, 80.0),
            ("Mung Beans", "pulses", 82.0, 95.0),
            ("Black Gram", "pulses", 66.0, 78.0),
            ("Mustard", "pulses", 54.0, 68.0),
            ("Soybean", "pulses", 44.0, 56.0),
            ("Potato", "vegetables", 12.0, 18.0),
            ("Onion", "vegetables", 15.0, 24.0),
            ("Tomato", "vegetables", 18.0, 30.0),
            ("Garlic", "vegetables", 75.0, 110.0),
            ("Ginger", "vegetables", 90.0, 130.0),
            ("Apple", "fruits", 85.0, 140.0),
            ("Mango", "fruits", 65.0, 110.0),
            ("Banana", "fruits", 22.0, 35.0),
            ("Chili", "pulses", 110.0, 150.0) # Category mapping
        ]
        
        products = []
        for j in range(40):
            farmer = random.choice(farmers)
            crop_name, category, min_p, max_p = random.choice(crops)
            qty = random.randint(200, 2500)
            price = round(random.uniform(min_p, max_p), 1)
            
            # Slightly perturb farm location for product listings
            lat = farmer.location_lat + random.uniform(-0.05, 0.05)
            lng = farmer.location_lng + random.uniform(-0.05, 0.05)
            
            harvest = date.today() - timedelta(days=random.randint(5, 30))
            
            # Placeholder photos
            photo_options = [
                "/static/images/placeholder_wheat.webp",
                "/static/images/placeholder_rice.webp",
                "/static/images/placeholder_potato.webp",
                "/static/images/placeholder_onion.webp"
            ]
            photo_url = random.choice(photo_options)
            
            product = Product(
                farmer_id=farmer.id,
                crop_name=crop_name,
                category=category,
                quantity_kg=float(qty),
                price_per_kg=float(price),
                description=f"Freshly harvested organic {crop_name} direct from {farmer.farm_name}. High quality, sorted and clean. Available for immediate purchase.",
                photo_url=photo_url,
                status='available' if random.random() > 0.15 else 'sold',
                harvest_date=harvest,
                location_lat=lat,
                location_lng=lng
            )
            db.session.add(product)
            products.append(product)
            
        print("40 Product listings seeded.")
        db.session.flush()

        # 5. Seed Market Prices (200 records spanning recent 30 days)
        # 10 Crops * 10 States * 2 records
        seed_crops = ["Wheat", "Paddy", "Maize", "Potato", "Onion", "Tomato", "Chickpeas", "Mung Beans", "Mustard", "Chili"]
        seed_states = ["Uttar Pradesh", "Punjab", "Haryana", "Rajasthan", "Madhya Pradesh", "Maharashtra", "Gujarat", "Andhra Pradesh", "Karnataka", "Tamil Nadu"]
        
        crop_base_q = {
            "Wheat": 2125, "Paddy": 2183, "Maize": 2090, "Potato": 1500, "Onion": 1800,
            "Tomato": 2200, "Chickpeas": 5335, "Mung Beans": 8558, "Mustard": 5450, "Chili": 12000
        }
        
        record_count = 0
        for crop in seed_crops:
            base = crop_base_q[crop]
            for state in seed_states:
                # Generate a few records over the last 30 days
                state_fact = 0.9 + random.random() * 0.2 # 0.9 to 1.1
                
                # record 1: 15 days ago
                price1 = base * state_fact * (0.95 + random.random() * 0.1)
                date1 = date.today() - timedelta(days=15)
                mp1 = MarketPrice(
                    crop_name=crop,
                    state=state,
                    price_per_quintal=round(price1, 2),
                    price_date=date1,
                    source="AGMARKNET Sourcing"
                )
                db.session.add(mp1)
                
                # record 2: today
                # slightly higher or lower to test coloring (green/red)
                price2 = price1 * (0.97 + random.random() * 0.06)
                mp2 = MarketPrice(
                    crop_name=crop,
                    state=state,
                    price_per_quintal=round(price2, 2),
                    price_date=date.today(),
                    source="AGMARKNET Sourcing"
                )
                db.session.add(mp2)
                record_count += 2

        print(f"{record_count} Market Price entries seeded.")

        # 6. Seed historical ML predictions (50 entries)
        pred_crops = ["Wheat", "Paddy", "Maize", "Potato", "Onion", "Tomato"]
        pred_states = ["Uttar Pradesh", "Punjab", "Madhya Pradesh", "Rajasthan"]
        for k in range(50):
            crop = random.choice(pred_crops)
            state = random.choice(pred_states)
            pred_p = crop_base_q[crop] * (0.9 + random.random() * 0.2) / 100.0 # per kg
            pred_date = date.today() + timedelta(days=random.randint(5, 60))
            conf = random.uniform(75, 96)
            
            prediction = PricePrediction(
                user_id=random.choice(farmers).user_id,
                crop_name=crop,
                predicted_price=round(pred_p, 2),
                prediction_date=pred_date,
                confidence_score=round(conf, 2),
                model_version="1.0.0",
                created_at=datetime.now(timezone.utc) - timedelta(days=random.randint(0, 10))
            )
            db.session.add(prediction)
        print("50 Historical predictions seeded.")

        # 7. Seed Orders
        # Let's seed 10 orders
        available_products = [p for p in products if p.status == 'available']
        for o in range(10):
            buyer = random.choice(buyers)
            product = random.choice(available_products)
            qty = random.randint(10, 100)
            total = qty * product.price_per_kg
            status = random.choice(['pending', 'confirmed', 'delivered'])
            
            order = Order(
                buyer_id=buyer.id,
                product_id=product.id,
                quantity_kg=float(qty),
                total_price=float(total),
                order_status=status,
                order_date=datetime.now(timezone.utc) - timedelta(days=random.randint(1, 10)),
                delivery_address=f"Agro-Processing Warehouse Block {o+1}, Industrial Area, Nagpur, Maharashtra"
            )
            db.session.add(order)
        print("10 Sample Orders seeded.")

        # 8. Seed Admin Logs
        for l in range(8):
            log = AdminLog(
                admin_id=admin.id,
                action=random.choice(["Approved Farmer Registration", "Removed Flagged Product", "Verified User Email", "Triggered ML Model Retraining"]),
                target_table="users" if random.random() > 0.5 else "products",
                target_id=random.randint(1, 10)
            )
            db.session.add(log)
        print("8 Admin logs seeded.")

        db.session.commit()
        print("Database seeding completed successfully.")

if __name__ == '__main__':
    seed_database()

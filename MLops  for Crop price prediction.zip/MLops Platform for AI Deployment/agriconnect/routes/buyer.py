from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from models import db, User, Farmer, Product, Order, MarketPrice
import math
from datetime import datetime

buyer_bp = Blueprint('buyer', __name__)

def haversine(lat1, lon1, lat2, lon2):
    """Calculate the great circle distance between two points on the earth in km."""
    if lat1 is None or lon1 is None or lat2 is None or lon2 is None:
        return float('inf')
    
    # Convert latitude and longitude to radians
    lat1, lon1, lat2, lon2 = map(math.radians, [float(lat1), float(lon1), float(lat2), float(lon2)])
    
    # Haversine formula
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
    c = 2 * math.asin(math.sqrt(a))
    r = 6371 # Radius of earth in kilometers
    return c * r

@buyer_bp.route('/home')
def home():
    # 1. Live Ticker: Get latest 10 market price records
    ticker_prices = MarketPrice.query.order_by(MarketPrice.price_date.desc()).limit(10).all()
    
    # 2. Featured Products: 8 latest available products
    featured_products = Product.query.filter_by(status='available')\
        .order_by(Product.listed_at.desc()).limit(8).all()
        
    # 3. Market Stats cards
    total_farmers = User.query.filter_by(role='farmer').count()
    total_products = Product.query.count()
    
    states_query = db.session.query(Farmer.state).distinct().all()
    states_covered = len(states_query) if states_query else 5
    
    successful_tx = Order.query.filter(Order.order_status.in_(['confirmed', 'delivered'])).count()
    
    return render_template(
        'home.html',
        ticker_prices=ticker_prices,
        featured_products=featured_products,
        total_farmers=total_farmers,
        total_products=total_products,
        states_covered=states_covered,
        successful_tx=successful_tx
    )

@buyer_bp.route('/products')
def products():
    # Read query/filter params
    category = request.args.get('category')
    state = request.args.get('state')
    search_query = request.args.get('search')
    min_price = request.args.get('min_price', type=float)
    max_price = request.args.get('max_price', type=float)
    sort_by = request.args.get('sort_by', 'latest')
    
    # Geolocation for nearest sort
    buyer_lat = request.args.get('lat', type=float)
    buyer_lng = request.args.get('lng', type=float)
    
    # Base query: only show available items
    query = Product.query.filter_by(status='available')
    
    # Apply category filter
    if category and category != 'all':
        query = query.filter(Product.category == category)
        
    # Apply search filter
    if search_query:
        query = query.filter(Product.crop_name.like(f"%{search_query}%"))
        
    # Apply state filter
    if state and state != 'all':
        query = query.join(Farmer).filter(Farmer.state == state)
        
    # Apply price filters
    if min_price is not None:
        query = query.filter(Product.price_per_kg >= min_price)
    if max_price is not None:
        query = query.filter(Product.price_per_kg <= max_price)
        
    # Execute query
    all_products = query.all()
    
    # Sort products
    if sort_by == 'price_asc':
        all_products.sort(key=lambda p: p.price_per_kg)
    elif sort_by == 'price_desc':
        all_products.sort(key=lambda p: p.price_per_kg, reverse=True)
    elif sort_by == 'nearest' and buyer_lat is not None and buyer_lng is not None:
        all_products.sort(key=lambda p: haversine(buyer_lat, buyer_lng, p.location_lat, p.location_lng))
    else: # Default: latest listed
        all_products.sort(key=lambda p: p.listed_at, reverse=True)
        
    # Fetch list of unique states for the state filter dropdown
    unique_states = [s[0] for s in db.session.query(Farmer.state).distinct().all()]
    
    return render_template(
        'buyer/products.html',
        products=all_products,
        states=unique_states,
        current_category=category or 'all',
        current_state=state or 'all',
        current_search=search_query or '',
        current_min_price=min_price,
        current_max_price=max_price,
        current_sort=sort_by,
        buyer_lat=buyer_lat,
        buyer_lng=buyer_lng
    )

@buyer_bp.route('/order/confirm/<int:order_id>')
@login_required
def order_confirm(order_id):
    order = Order.query.filter_by(id=order_id, buyer_id=current_user.id).first_or_404()
    return render_template('buyer/order_confirm.html', order=order)

# --- API ENDPOINTS ---
@buyer_bp.route('/api/products')
def api_products():
    """Returns a list of products in JSON format for live filtering."""
    products_list = Product.query.filter_by(status='available').all()
    data = []
    for p in products_list:
        data.append({
            'id': p.id,
            'crop_name': p.crop_name,
            'category': p.category,
            'price_per_kg': p.price_per_kg,
            'quantity_kg': p.quantity_kg,
            'farm_name': p.farmer.farm_name,
            'state': p.farmer.state,
            'district': p.farmer.district,
            'lat': p.location_lat,
            'lng': p.location_lng,
            'photo_url': p.photo_url
        })
    return jsonify(data)

@buyer_bp.route('/api/products/<int:product_id>')
def api_product_detail(product_id):
    p = Product.query.get_or_404(product_id)
    return jsonify({
        'id': p.id,
        'crop_name': p.crop_name,
        'category': p.category,
        'price_per_kg': p.price_per_kg,
        'quantity_kg': p.quantity_kg,
        'description': p.description,
        'harvest_date': p.harvest_date.strftime('%Y-%m-%d'),
        'photo_url': p.photo_url,
        'status': p.status,
        'farmer_name': p.farmer.user.full_name,
        'farm_name': p.farmer.farm_name,
        'state': p.farmer.state,
        'district': p.farmer.district,
        'lat': p.location_lat,
        'lng': p.location_lng,
        'phone': p.farmer.user.phone
    })

@buyer_bp.route('/api/orders/create', methods=['POST'])
@login_required
def create_order_api():
    if current_user.role != 'buyer':
        return jsonify({'success': False, 'message': 'Only buyers can purchase products.'}), 403
        
    data = request.json or {}
    product_id = data.get('product_id')
    quantity_str = data.get('quantity_kg')
    delivery_address = data.get('delivery_address', '').strip()
    
    if not product_id or not quantity_str or not delivery_address:
        return jsonify({'success': False, 'message': 'All order fields are required.'}), 400
        
    product = Product.query.get(product_id)
    if not product or product.status != 'available':
        return jsonify({'success': False, 'message': 'Product is not available.'}), 404
        
    try:
        quantity = float(quantity_str)
    except ValueError:
        return jsonify({'success': False, 'message': 'Invalid quantity.'}), 400
        
    if quantity <= 0:
        return jsonify({'success': False, 'message': 'Quantity must be greater than zero.'}), 400
        
    if quantity > product.quantity_kg:
        return jsonify({'success': False, 'message': f'Only {product.quantity_kg} kg available.'}), 400
        
    total_price = quantity * product.price_per_kg
    
    # Create order
    order = Order(
        buyer_id=current_user.id,
        product_id=product.id,
        quantity_kg=quantity,
        total_price=total_price,
        order_status='pending',
        delivery_address=delivery_address
    )
    
    # Deduct quantity from product
    product.quantity_kg -= quantity
    if product.quantity_kg <= 0.01:
        product.quantity_kg = 0
        product.status = 'sold'
        
    db.session.add(order)
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': 'Order placed successfully!',
        'order_id': order.id
    })

@buyer_bp.route('/api/orders/buyer')
@login_required
def buyer_orders_api():
    if current_user.role != 'buyer':
        return jsonify({'success': False, 'message': 'Forbidden.'}), 403
    orders_list = Order.query.filter_by(buyer_id=current_user.id).order_by(Order.order_date.desc()).all()
    data = []
    for o in orders_list:
        data.append({
            'id': o.id,
            'crop_name': o.product.crop_name,
            'farmer_name': o.product.farmer.user.full_name,
            'quantity_kg': o.quantity_kg,
            'total_price': o.total_price,
            'status': o.order_status,
            'date': o.order_date.strftime('%Y-%m-%d %H:%M')
        })
    return jsonify(data)

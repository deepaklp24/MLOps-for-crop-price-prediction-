from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify, current_app
from flask_login import login_required, current_user
from models import db, User, Farmer, Product, Order, MarketPrice
from routes.utils import farmer_required, allowed_file
import os
import uuid
from datetime import datetime

farmer_bp = Blueprint('farmer', __name__, url_prefix='/farmer')

@farmer_bp.before_request
@login_required
@farmer_required
def before_request():
    """Ensure all routes in this blueprint require login and farmer role."""
    pass

@farmer_bp.route('/dashboard')
def dashboard():
    farmer = current_user.farmer_profile
    
    # Calculate stats
    total_listed = Product.query.filter_by(farmer_id=farmer.id).count()
    active_listings = Product.query.filter_by(farmer_id=farmer.id, status='available').count()
    
    # Fetch orders for this farmer's products
    farmer_orders_query = Order.query.join(Product).filter(Product.farmer_id == farmer.id)
    total_orders = farmer_orders_query.count()
    
    # Revenue is sum of confirmed or delivered orders
    revenue_query = db.session.query(db.func.sum(Order.total_price)).join(Product)\
        .filter(Product.farmer_id == farmer.id)\
        .filter(Order.order_status.in_(['confirmed', 'delivered'])).scalar()
    total_revenue = float(revenue_query) if revenue_query else 0.0
    
    # Recent orders
    recent_orders = farmer_orders_query.order_by(Order.order_date.desc()).limit(5).all()
    
    # Get top crop name for price trend mini-chart
    # We find the crop with the most quantity listed by this farmer
    top_crop_query = db.session.query(Product.crop_name, db.func.sum(Product.quantity_kg))\
        .filter(Product.farmer_id == farmer.id)\
        .group_by(Product.crop_name)\
        .order_by(db.func.sum(Product.quantity_kg).desc()).first()
        
    top_crop = top_crop_query[0] if top_crop_query else "Wheat"
    
    # Fetch price trends for the top crop in the farmer's state
    # Fallback to general price trend if state has no data
    trends = MarketPrice.query.filter_by(crop_name=top_crop, state=farmer.state)\
        .order_by(MarketPrice.price_date.asc()).limit(10).all()
    if not trends:
        trends = MarketPrice.query.filter_by(crop_name=top_crop)\
            .order_by(MarketPrice.price_date.asc()).limit(10).all()
            
    trend_labels = [t.price_date.strftime('%d %b') for t in trends]
    trend_values = [t.price_per_quintal / 100.0 for t in trends] # per kg

    return render_template(
        'farmer/dashboard.html',
        farmer=farmer,
        total_listed=total_listed,
        active_listings=active_listings,
        total_orders=total_orders,
        total_revenue=total_revenue,
        recent_orders=recent_orders,
        top_crop=top_crop,
        trend_labels=trend_labels,
        trend_values=trend_values
    )

@farmer_bp.route('/products')
def products():
    farmer = current_user.farmer_profile
    category_filter = request.args.get('category')
    status_filter = request.args.get('status')
    
    query = Product.query.filter_by(farmer_id=farmer.id)
    if category_filter:
        query = query.filter_by(category=category_filter)
    if status_filter:
        query = query.filter_by(status=status_filter)
        
    farmer_products = query.order_by(Product.listed_at.desc()).all()
    return render_template('farmer/products.html', products=farmer_products, current_category=category_filter, current_status=status_filter)

@farmer_bp.route('/products/add', methods=['GET', 'POST'])
def add_product():
    farmer = current_user.farmer_profile
    if request.method == 'POST':
        crop_name = request.form.get('crop_name', '').strip()
        category = request.form.get('category', '')
        quantity = request.form.get('quantity_kg', '')
        price = request.form.get('price_per_kg', '')
        description = request.form.get('description', '').strip()
        harvest_date_str = request.form.get('harvest_date', '')
        
        lat_str = request.form.get('location_lat', '')
        lng_str = request.form.get('location_lng', '')
        
        # Validation
        if not crop_name or not category or not quantity or not price or not harvest_date_str:
            flash("All required fields must be filled.", "danger")
            return render_template('farmer/add_product.html')
            
        try:
            quantity = float(quantity)
            price = float(price)
            harvest_date = datetime.strptime(harvest_date_str, "%Y-%m-%d").date()
            lat = float(lat_str) if lat_str else farmer.location_lat
            lng = float(lng_str) if lng_str else farmer.location_lng
        except ValueError:
            flash("Invalid quantity, price, harvest date, or location coordinates.", "danger")
            return render_template('farmer/add_product.html')
            
        # Image Upload
        photo_file = request.files.get('photo')
        photo_url = "/static/images/placeholder_wheat.webp" # Default fallback
        
        if photo_file and photo_file.filename:
            if allowed_file(photo_file.filename):
                filename = f"crop_{uuid.uuid4().hex}_{photo_file.filename}"
                upload_path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
                photo_file.save(upload_path)
                photo_url = f"/static/uploads/{filename}"
            else:
                flash("Invalid image file format. Only JPG, PNG, and WEBP are allowed.", "danger")
                return render_template('farmer/add_product.html')
                
        product = Product(
            farmer_id=farmer.id,
            crop_name=crop_name,
            category=category,
            quantity_kg=quantity,
            price_per_kg=price,
            description=description,
            photo_url=photo_url,
            status='available',
            harvest_date=harvest_date,
            location_lat=lat,
            location_lng=lng
        )
        
        db.session.add(product)
        db.session.commit()
        flash("Product listing added successfully!", "success")
        return redirect(url_for('farmer.products'))
        
    return render_template('farmer/add_product.html', farmer=farmer)

@farmer_bp.route('/orders')
def orders():
    farmer = current_user.farmer_profile
    status_filter = request.args.get('status')
    
    query = Order.query.join(Product).filter(Product.farmer_id == farmer.id)
    if status_filter:
        query = query.filter(Order.order_status == status_filter)
        
    farmer_orders = query.order_by(Order.order_date.desc()).all()
    return render_template('farmer/orders.html', orders=farmer_orders, current_status=status_filter)

@farmer_bp.route('/location')
def location():
    farmer = current_user.farmer_profile
    
    # Get coordinates of buyers who have ordered from this farmer
    buyer_orders = Order.query.join(Product).filter(Product.farmer_id == farmer.id).all()
    
    # Gather unique buyer coordinates
    buyers_coords = []
    seen_buyers = set()
    for o in buyer_orders:
        buyer = o.buyer
        if buyer.id not in seen_buyers:
            seen_buyers.add(buyer.id)
            # Find a product listed by this farmer with location, or associate a generic coordinate
            # We can associate their delivery address or generic coordinates from their region
            # For demo maps, we will perturb the farmer location slightly to place them nearby on the map
            import random
            buyers_coords.append({
                'id': buyer.id,
                'name': buyer.full_name,
                'crop': o.product.crop_name,
                'qty': o.quantity_kg,
                'lat': farmer.location_lat + random.uniform(-0.15, 0.15) if farmer.location_lat else 20.0 + random.uniform(-1, 1),
                'lng': farmer.location_lng + random.uniform(-0.15, 0.15) if farmer.location_lng else 78.0 + random.uniform(-1, 1)
            })

    return render_template('farmer/location.html', farmer=farmer, buyers_coords=buyers_coords)

# --- API ENDPOINTS ---
@farmer_bp.route('/api/products/<int:product_id>', methods=['PUT'])
def edit_product_api(product_id):
    farmer = current_user.farmer_profile
    product = Product.query.filter_by(id=product_id, farmer_id=farmer.id).first()
    if not product:
        return jsonify({'success': False, 'message': 'Product not found.'}), 404
        
    data = request.json or {}
    
    # Toggle status if that's what's passed
    if 'status' in data:
        status = data['status']
        if status in ['available', 'sold', 'hidden']:
            product.status = status
            db.session.commit()
            return jsonify({'success': True, 'message': f'Status updated to {status}.'})
        return jsonify({'success': False, 'message': 'Invalid status.'}), 400
        
    # Standard field update
    product.crop_name = data.get('crop_name', product.crop_name)
    product.category = data.get('category', product.category)
    if 'quantity_kg' in data:
        product.quantity_kg = float(data['quantity_kg'])
    if 'price_per_kg' in data:
        product.price_per_kg = float(data['price_per_kg'])
    product.description = data.get('description', product.description)
    if 'harvest_date' in data:
        product.harvest_date = datetime.strptime(data['harvest_date'], "%Y-%m-%d").date()
        
    db.session.commit()
    return jsonify({'success': True, 'message': 'Product updated successfully.'})

@farmer_bp.route('/api/products/<int:product_id>', methods=['DELETE'])
def delete_product_api(product_id):
    farmer = current_user.farmer_profile
    product = Product.query.filter_by(id=product_id, farmer_id=farmer.id).first()
    if not product:
        return jsonify({'success': False, 'message': 'Product not found.'}), 404
        
    db.session.delete(product)
    db.session.commit()
    return jsonify({'success': True, 'message': 'Product deleted successfully.'})

@farmer_bp.route('/api/orders/<int:order_id>/status', methods=['PUT'])
def update_order_status_api(order_id):
    farmer = current_user.farmer_profile
    order = Order.query.join(Product).filter(Product.farmer_id == farmer.id).filter(Order.id == order_id).first()
    
    if not order:
        return jsonify({'success': False, 'message': 'Order not found.'}), 404
        
    data = request.json or {}
    new_status = data.get('status')
    
    if new_status not in ['pending', 'confirmed', 'delivered']:
        return jsonify({'success': False, 'message': 'Invalid status.'}), 400
        
    order.order_status = new_status
    
    # If order is delivered, we can optionally mark the product as sold if quantity is exhausted
    if new_status == 'delivered':
        # Simple rule: if this order takes all or most, or just mark product sold for simplicity
        # Let's say if it's delivered, we can check or keep it
        pass
        
    db.session.commit()
    return jsonify({'success': True, 'message': f'Order status updated to {new_status}.'})

@farmer_bp.route('/api/farmer/location', methods=['PUT'])
def update_location_api():
    farmer = current_user.farmer_profile
    data = request.json or {}
    
    lat = data.get('lat')
    lng = data.get('lng')
    address = data.get('address')
    state = data.get('state')
    district = data.get('district')
    
    if lat is None or lng is None:
        return jsonify({'success': False, 'message': 'Coordinates missing.'}), 400
        
    farmer.location_lat = float(lat)
    farmer.location_lng = float(lng)
    
    if address:
        farmer.address = address
    if state:
        farmer.state = state
    if district:
        farmer.district = district
        
    db.session.commit()
    return jsonify({'success': True, 'message': 'Land location updated successfully.'})

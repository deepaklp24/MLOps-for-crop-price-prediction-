from datetime import datetime, timedelta, timezone
import random
import re
from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify, session
from flask_login import login_user, logout_user, login_required, current_user
from models import db, User, Farmer
from routes.utils import allowed_file
import uuid
import os

auth_bp = Blueprint('auth', __name__)

def validate_password_strength(password):
    """Verify password has >=8 chars, uppercase, lowercase, number, and special character."""
    if len(password) < 8:
        return False
    if not re.search("[a-z]", password):
        return False
    if not re.search("[A-Z]", password):
        return False
    if not re.search("[0-9]", password):
        return False
    if not re.search("[_@$!%*#?&]", password):
        return False
    return True

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('buyer.home'))
        
    if request.method == 'POST':
        full_name = request.form.get('full_name', '').strip()
        email = request.form.get('email', '').strip()
        phone = request.form.get('phone', '').strip()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')
        role = request.form.get('role', '') # 'farmer' or 'buyer'
        
        # Server-side validation
        if not full_name or not email or not phone or not password or not role:
            flash("All fields are required.", "danger")
            return render_template('auth/register.html')
            
        if password != confirm_password:
            flash("Passwords do not match.", "danger")
            return render_template('auth/register.html')
            
        if not validate_password_strength(password):
            flash("Password must be at least 8 characters long, contain at least one uppercase letter, one lowercase letter, one number, and one special character.", "danger")
            return render_template('auth/register.html')
            
        if User.query.filter_by(email=email).first():
            flash("Email already registered.", "danger")
            return render_template('auth/register.html')
            
        # Create User
        user = User(
            full_name=full_name,
            email=email,
            phone=phone,
            role=role,
            is_verified=False
        )
        user.set_password(password)
        
        db.session.add(user)
        db.session.flush() # Get user.id
        
        # Farmer specific profile creation
        if role == 'farmer':
            farm_name = request.form.get('farm_name', '').strip()
            farm_size = request.form.get('farm_size', '').strip()
            state = request.form.get('state', '').strip()
            district = request.form.get('district', '').strip()
            address = request.form.get('address', '').strip()
            lat_str = request.form.get('location_lat', '')
            lng_str = request.form.get('location_lng', '')
            
            if not farm_name or not farm_size or not state or not district or not address:
                db.session.rollback()
                flash("Farm details are required for farmers.", "danger")
                return render_template('auth/register.html')
                
            try:
                lat = float(lat_str) if lat_str else None
                lng = float(lng_str) if lng_str else None
                farm_size = float(farm_size)
            except ValueError:
                db.session.rollback()
                flash("Invalid lat/lng or farm size values.", "danger")
                return render_template('auth/register.html')
                
            # Handle land document upload if present
            land_doc_file = request.files.get('land_document')
            land_doc_url = None
            if land_doc_file and land_doc_file.filename:
                if allowed_file(land_doc_file.filename):
                    filename = f"doc_{uuid.uuid4().hex}_{land_doc_file.filename}"
                    from flask import current_app
                    upload_path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
                    land_doc_file.save(upload_path)
                    land_doc_url = f"/static/uploads/{filename}"
                else:
                    db.session.rollback()
                    flash("Invalid land document file type. Upload PDF, JPG, PNG or WEBP.", "danger")
                    return render_template('auth/register.html')
            
            farmer = Farmer(
                user_id=user.id,
                farm_name=farm_name,
                location_lat=lat,
                location_lng=lng,
                farm_size_acres=farm_size,
                address=address,
                state=state,
                district=district,
                land_document_url=land_doc_url
            )
            db.session.add(farmer)
            
        db.session.commit()
        flash("Registration successful! Please login.", "success")
        return redirect(url_for('auth.login'))
        
    return render_template('auth/register.html')

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        if current_user.role == 'farmer':
            return redirect(url_for('farmer.dashboard'))
        elif current_user.role == 'admin':
            return redirect(url_for('admin.dashboard'))
        else:
            return redirect(url_for('buyer.home'))

    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        remember = True if request.form.get('remember') else False
        
        user = User.query.filter_by(email=email).first()
        
        if not user:
            flash("Invalid email or password.", "danger")
            return render_template('auth/login.html')
            
        # Check lockout
        if user.is_locked_out():
            time_left = user.lockout_until.replace(tzinfo=timezone.utc) - datetime.now(timezone.utc)
            minutes_left = max(1, int(time_left.total_seconds() / 60))
            flash(f"Account locked out. Try again in {minutes_left} minutes.", "danger")
            return render_template('auth/login.html')
            
        # Verify credentials
        if user.check_password(password):
            # Reset failed attempts
            user.failed_login_attempts = 0
            user.lockout_until = None
            db.session.commit()
            
            login_user(user, remember=remember)
            
            # Role redirection
            if user.role == 'farmer':
                flash(f"Welcome back, {user.full_name}!", "success")
                return redirect(url_for('farmer.dashboard'))
            elif user.role == 'admin':
                flash("Admin Panel loaded.", "success")
                return redirect(url_for('admin.dashboard'))
            else:
                flash(f"Welcome back, {user.full_name}!", "success")
                return redirect(url_for('buyer.home'))
        else:
            # Increment failed attempts
            user.failed_login_attempts += 1
            remaining_attempts = 5 - user.failed_login_attempts
            
            if user.failed_login_attempts >= 5:
                user.lockout_until = datetime.now(timezone.utc) + timedelta(minutes=15)
                db.session.commit()
                flash("Too many failed attempts. Account locked for 15 minutes.", "danger")
            else:
                db.session.commit()
                flash(f"Invalid email or password. {remaining_attempts} attempts remaining.", "danger")
                
            return render_template('auth/login.html')
            
    return render_template('auth/login.html')

@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash("You have been logged out.", "info")
    return redirect(url_for('buyer.home'))

@auth_bp.route('/forgot-password')
def forgot_password_page():
    return render_template('auth/forgot_password.html')

# --- API ENDPOINTS ---
@auth_bp.route('/api/auth/forgot-password', methods=['POST'])
def forgot_password_api():
    email = request.json.get('email', '').strip()
    user = User.query.filter_by(email=email).first()
    
    if not user:
        return jsonify({'success': False, 'message': 'Email address not found.'}), 404
        
    # Generate 6-digit OTP
    otp = str(random.randint(100000, 999999))
    session['reset_email'] = email
    session['reset_otp'] = otp
    session['reset_otp_expiry'] = (datetime.now(timezone.utc) + timedelta(minutes=5)).isoformat()
    session['otp_verified'] = False
    
    print("\n" + "="*50)
    print(f" OTP CODE FOR {email}:  {otp} ")
    print("="*50 + "\n")
    
    return jsonify({'success': True, 'message': 'OTP sent! Check terminal output.'})

@auth_bp.route('/api/auth/verify-otp', methods=['POST'])
def verify_otp_api():
    otp_entered = request.json.get('otp', '').strip()
    session_otp = session.get('reset_otp')
    expiry_str = session.get('reset_otp_expiry')
    
    if not session_otp or not expiry_str:
        return jsonify({'success': False, 'message': 'No OTP session found. Start over.'}), 400
        
    expiry = datetime.fromisoformat(expiry_str)
    if datetime.now(timezone.utc) > expiry.replace(tzinfo=timezone.utc) if expiry.tzinfo is None else expiry:
        return jsonify({'success': False, 'message': 'OTP has expired. Please request a new one.'}), 400
        
    if otp_entered == session_otp:
        session['otp_verified'] = True
        return jsonify({'success': True, 'message': 'OTP verified successfully.'})
    else:
        return jsonify({'success': False, 'message': 'Invalid OTP code. Try again.'}), 400

@auth_bp.route('/api/auth/reset-password', methods=['POST'])
def reset_password_api():
    if not session.get('otp_verified'):
        return jsonify({'success': False, 'message': 'OTP has not been verified.'}), 403
        
    password = request.json.get('password', '')
    confirm_password = request.json.get('confirm_password', '')
    email = session.get('reset_email')
    
    if not password or password != confirm_password:
        return jsonify({'success': False, 'message': 'Passwords do not match or are empty.'}), 400
        
    if not validate_password_strength(password):
        return jsonify({'success': False, 'message': 'Password does not meet safety guidelines.'}), 400
        
    user = User.query.filter_by(email=email).first()
    if not user:
        return jsonify({'success': False, 'message': 'User not found.'}), 404
        
    user.set_password(password)
    user.failed_login_attempts = 0
    user.lockout_until = None
    db.session.commit()
    
    # Clear session values
    session.pop('reset_email', None)
    session.pop('reset_otp', None)
    session.pop('reset_otp_expiry', None)
    session.pop('otp_verified', None)
    
    return jsonify({'success': True, 'message': 'Password reset successful!'})

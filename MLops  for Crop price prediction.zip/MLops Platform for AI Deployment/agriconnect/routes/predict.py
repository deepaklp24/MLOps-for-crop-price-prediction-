from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from models import db, PricePrediction, Farmer
from ml.predict import predict_crop_price
from datetime import datetime, timedelta, date

predict_bp = Blueprint('predict', __name__)

@predict_bp.route('/predict')
@login_required
def predict_page():
    # 30+ Crops list
    crops = [
        'Wheat', 'Paddy', 'Maize', 'Barley', 'Millet', 'Sorghum', 'Chickpeas', 
        'Pigeon Peas', 'Mung Beans', 'Black Gram', 'Lentils', 'Mustard', 'Groundnut', 
        'Soybean', 'Sunflower', 'Cotton', 'Jute', 'Sugarcane', 'Potato', 'Onion', 
        'Tomato', 'Garlic', 'Ginger', 'Turmeric', 'Coriander', 'Chili', 'Cabbage', 
        'Cauliflower', 'Apple', 'Mango', 'Banana'
    ]
    
    # 20 States
    states = [
        'Uttar Pradesh', 'Madhya Pradesh', 'Punjab', 'Haryana', 'Rajasthan', 
        'Bihar', 'West Bengal', 'Maharashtra', 'Gujarat', 'Andhra Pradesh', 
        'Telangana', 'Karnataka', 'Tamil Nadu', 'Kerala', 'Odisha', 
        'Chhattisgarh', 'Jharkhand', 'Assam', 'Himachal Pradesh', 'Jammu and Kashmir'
    ]
    
    # Pre-fill farmer state if available
    user_state = ""
    if current_user.role == 'farmer' and current_user.farmer_profile:
        user_state = current_user.farmer_profile.state
        
    return render_template('predict.html', crops=crops, states=states, default_state=user_state)

# --- API ENDPOINTS ---
@predict_bp.route('/api/predict/price', methods=['GET', 'POST'])
@login_required
def api_predict_price():
    if request.method == 'GET':
        crop_name = request.args.get('crop') or request.args.get('crop_name')
        state = request.args.get('state')
        if not state:
            if current_user.role == 'farmer' and current_user.farmer_profile:
                state = current_user.farmer_profile.state
            else:
                state = 'Uttar Pradesh'
        target_date_str = request.args.get('target_date') or date.today().strftime("%Y-%m-%d")
        season_str = request.args.get('season')
        quantity_str = request.args.get('quantity_kg')
    else:
        data = request.json or {}
        crop_name = data.get('crop_name')
        state = data.get('state')
        target_date_str = data.get('target_date')
        season_str = data.get('season')  # Optional
        quantity_str = data.get('quantity_kg')  # Optional
    
    if not crop_name or not state or not target_date_str:
        return jsonify({'success': False, 'message': 'Missing required fields: Crop Name, State, and Date.'}), 400
        
    # Parse quantity if entered
    quantity = 0.0
    if quantity_str:
        try:
            quantity = float(quantity_str)
        except ValueError:
            return jsonify({'success': False, 'message': 'Invalid quantity.'}), 400
            
    # Season mapping
    # 'Kharif' -> 0, 'Rabi' -> 1, 'Zaid' -> 2
    season_map = {'Kharif': 0, 'Rabi': 1, 'Zaid': 2}
    season = season_map.get(season_str)
    
    try:
        # Perform prediction using ML backend
        # We will use average rainfall/demand indices (e.g. 0.6 and 0.75) for typical prediction
        pred_res = predict_crop_price(
            crop_name=crop_name,
            state=state,
            target_date_str=target_date_str,
            season=season,
            rainfall_index=0.55,
            demand_score=0.72
        )
        
        # Calculate revenue if quantity provided
        estimated_revenue = 0.0
        if quantity > 0:
            estimated_revenue = round(pred_res['predicted_price_kg'] * quantity, 2)
            
        # Store prediction in price_predictions table for audit trail
        # Map predicted price per kg to predicted price in database (per kg or per quintal?
        # Database schema has predicted_price. We store it as predicted price per kg for simplicity)
        pred_date = datetime.strptime(target_date_str, "%Y-%m-%d").date()
        
        audit_record = PricePrediction(
            user_id=current_user.id,
            crop_name=crop_name,
            predicted_price=pred_res['predicted_price_kg'],
            prediction_date=pred_date,
            confidence_score=pred_res['confidence_score'],
            model_version=pred_res['model_version'] or '1.0.0'
        )
        db.session.add(audit_record)
        db.session.commit()
        
        # Generate 30-day forecast sequence starting from today (or target_date - 15 days to +15 days)
        # We will generate a 30-day sequence starting from today to show the trend
        forecast_data = []
        today = date.today()
        for i in range(30):
            forecast_date = today + timedelta(days=i)
            f_date_str = forecast_date.strftime("%Y-%m-%d")
            
            # Predict for sequence with slight variations to make chart look dynamic
            # We can vary demand score slightly over the 30 days
            demand_var = 0.72 + 0.1 * math.sin(i / 5.0)
            day_pred = predict_crop_price(
                crop_name=crop_name,
                state=state,
                target_date_str=f_date_str,
                season=season,
                rainfall_index=0.55,
                demand_score=demand_var
            )
            
            forecast_data.append({
                'date': forecast_date.strftime('%d %b'),
                'price': day_pred['predicted_price_kg'],
                'min_price': day_pred['min_price_kg'],
                'max_price': day_pred['max_price_kg']
            })
            
        return jsonify({
            'success': True,
            'prediction': {
                'price_per_kg': pred_res['predicted_price_kg'],
                'confidence': pred_res['confidence_score'],
                'min_price': pred_res['min_price_kg'],
                'max_price': pred_res['max_price_kg'],
                'recommendation': pred_res['recommendation'],
                'estimated_revenue': estimated_revenue,
                'crop_name': crop_name,
                'state': state
            },
            'forecast': forecast_data
        })
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'Prediction model error: {str(e)}'}), 500

import math

@predict_bp.route('/api/predict/history')
@login_required
def api_predict_history():
    history = PricePrediction.query.filter_by(user_id=current_user.id)\
        .order_by(PricePrediction.created_at.desc()).limit(20).all()
        
    data = []
    for h in history:
        data.append({
            'id': h.id,
            'crop_name': h.crop_name,
            'predicted_price': h.predicted_price,
            'prediction_date': h.prediction_date.strftime('%Y-%m-%d'),
            'confidence_score': h.confidence_score,
            'created_at': h.created_at.strftime('%Y-%m-%d %H:%M')
        })
    return jsonify(data)

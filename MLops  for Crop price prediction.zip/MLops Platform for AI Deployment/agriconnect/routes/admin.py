from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify, current_app, send_from_directory
from flask_login import login_required, current_user
from models import db, User, Farmer, Product, Order, MarketPrice, PricePrediction, AdminLog
from routes.utils import admin_required
import os
import csv
import threading
from datetime import datetime, date, timedelta, timezone

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

@admin_bp.before_request
@login_required
@admin_required
def before_request():
    """Ensure all routes in this blueprint require login and admin role."""
    pass

@admin_bp.route('/dashboard')
def dashboard():
    # KPI metrics
    total_users = User.query.count()
    total_farmers = User.query.filter_by(role='farmer').count()
    total_buyers = User.query.filter_by(role='buyer').count()
    active_listings = Product.query.filter_by(status='available').count()
    
    today = date.today()
    orders_today = Order.query.filter(db.func.date(Order.order_date) == today).count()
    
    # Revenue this month
    first_of_month = date.today().replace(day=1)
    revenue_month_query = db.session.query(db.func.sum(Order.total_price))\
        .filter(Order.order_date >= first_of_month)\
        .filter(Order.order_status.in_(['confirmed', 'delivered'])).scalar()
    revenue_month = float(revenue_month_query) if revenue_month_query else 0.0
    
    # Recent activity log
    recent_logs = AdminLog.query.order_by(AdminLog.timestamp.desc()).limit(10).all()
    
    # Registrations per week (mock data or query)
    # Let's count actual signups in the last 4 weeks
    reg_counts = []
    reg_weeks = []
    for i in range(4):
        start_d = datetime.now(timezone.utc) - timedelta(weeks=i+1)
        end_d = datetime.now(timezone.utc) - timedelta(weeks=i)
        count = User.query.filter(User.created_at >= start_d).filter(User.created_at < end_d).count()
        reg_counts.append(count)
        reg_weeks.append(f"Week -{i}")
    reg_counts.reverse()
    reg_weeks.reverse()
    
    # Pie chart: Category counts
    category_data = db.session.query(Product.category, db.func.count(Product.id))\
        .group_by(Product.category).all()
        
    categories = [c[0] for c in category_data]
    category_counts = [c[1] for c in category_data]
    
    return render_template(
        'admin/dashboard.html',
        total_users=total_users,
        total_farmers=total_farmers,
        total_buyers=total_buyers,
        active_listings=active_listings,
        orders_today=orders_today,
        revenue_month=revenue_month,
        recent_logs=recent_logs,
        reg_weeks=reg_weeks,
        reg_counts=reg_counts,
        categories=categories,
        category_counts=category_counts
    )

@admin_bp.route('/users')
def users():
    all_users = User.query.order_by(User.created_at.desc()).all()
    return render_template('admin/users.html', users=all_users)

@admin_bp.route('/farmers')
def farmers():
    all_farmers = Farmer.query.join(User).order_by(User.created_at.desc()).all()
    return render_template('admin/farmers.html', farmers=all_farmers)

@admin_bp.route('/products')
def products():
    all_products = Product.query.order_by(Product.listed_at.desc()).all()
    return render_template('admin/products.html', products=all_products)

@admin_bp.route('/market')
def market():
    all_prices = MarketPrice.query.order_by(MarketPrice.price_date.desc()).limit(100).all()
    # List of unique crop names and states
    crops = sorted(list({p.crop_name for p in MarketPrice.query.all()}))
    states = sorted(list({p.state for p in MarketPrice.query.all()}))
    return render_template('admin/market.html', prices=all_prices, crops=crops, states=states)

@admin_bp.route('/ml-model')
def ml_model():
    ml_dir = os.path.join(current_app.root_path, 'ml')
    model_path = os.path.join(ml_dir, 'crop_price_model.pkl')
    
    metrics = {
        'r2': 0.0,
        'mae': 0.0,
        'rmse': 0.0,
        'num_samples': 0,
        'last_trained': 'Never'
    }
    
    if os.path.exists(model_path):
        import joblib
        try:
            artifacts = joblib.load(model_path)
            stats = artifacts.get('metrics', {})
            metrics['r2'] = stats.get('r2', 0.88)
            metrics['mae'] = stats.get('mae', 150.0)
            metrics['rmse'] = stats.get('rmse', 210.0)
            metrics['num_samples'] = stats.get('num_samples', 5000)
            mtime = os.path.getmtime(model_path)
            metrics['last_trained'] = datetime.fromtimestamp(mtime).strftime('%Y-%m-%d %H:%M:%S')
        except Exception:
            pass
            
    # Mock model versions table
    versions = [
        {'version': '1.0.0', 'date': metrics['last_trained'], 'r2': metrics['r2'], 'status': 'Active'},
        {'version': '0.9.1', 'date': '2026-05-10 14:00:23', 'r2': 0.84, 'status': 'Archived'}
    ]
    
    return render_template('admin/ml_model.html', metrics=metrics, versions=versions)

@admin_bp.route('/reports')
def reports():
    # Sales by crop
    sales_data = db.session.query(Product.crop_name, db.func.sum(Order.total_price))\
        .join(Order).filter(Order.order_status == 'delivered')\
        .group_by(Product.crop_name)\
        .order_by(db.func.sum(Order.total_price).desc()).limit(5).all()
        
    top_crops = [s[0] for s in sales_data]
    top_crop_sales = [float(s[1]) for s in sales_data]
    
    # Top farmers
    farmer_sales = db.session.query(Farmer.farm_name, db.func.sum(Order.total_price))\
        .join(Product).join(Order).filter(Order.order_status == 'delivered')\
        .group_by(Farmer.farm_name)\
        .order_by(db.func.sum(Order.total_price).desc()).limit(5).all()
        
    top_farmers = [f[0] for f in farmer_sales]
    top_farmer_sales = [float(f[1]) for f in farmer_sales]

    return render_template(
        'admin/reports.html',
        top_crops=top_crops,
        top_crop_sales=top_crop_sales,
        top_farmers=top_farmers,
        top_farmer_sales=top_farmer_sales
    )

# --- API ENDPOINTS & ACTIONS ---

@admin_bp.route('/api/users/<int:user_id>/status', methods=['PUT'])
def toggle_user_status(user_id):
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        return jsonify({'success': False, 'message': 'Cannot modify your own status.'}), 400
        
    data = request.json or {}
    action = data.get('action') # 'verify', 'deactivate', 'delete'
    
    if action == 'verify':
        user.is_verified = True
        log = AdminLog(admin_id=current_user.id, action=f"Verified user: {user.email}", target_table="users", target_id=user.id)
        db.session.add(log)
        db.session.commit()
        return jsonify({'success': True, 'message': f'User {user.full_name} verified.'})
        
    elif action == 'deactivate':
        user.is_verified = False
        log = AdminLog(admin_id=current_user.id, action=f"Deactivated user: {user.email}", target_table="users", target_id=user.id)
        db.session.add(log)
        db.session.commit()
        return jsonify({'success': True, 'message': f'User {user.full_name} deactivated.'})
        
    elif action == 'delete':
        db.session.delete(user)
        log = AdminLog(admin_id=current_user.id, action=f"Deleted user ID: {user_id}", target_table="users", target_id=user_id)
        db.session.add(log)
        db.session.commit()
        return jsonify({'success': True, 'message': 'User deleted successfully.'})
        
    return jsonify({'success': False, 'message': 'Invalid action.'}), 400

@admin_bp.route('/api/products/<int:product_id>/moderation', methods=['PUT'])
def moderate_product(product_id):
    product = Product.query.get_or_404(product_id)
    data = request.json or {}
    action = data.get('action') # 'approve', 'remove', 'flag'
    
    if action == 'approve':
        product.status = 'available'
        msg = "Product approved."
    elif action == 'remove':
        db.session.delete(product)
        log = AdminLog(admin_id=current_user.id, action=f"Removed product ID: {product_id}", target_table="products", target_id=product_id)
        db.session.add(log)
        db.session.commit()
        return jsonify({'success': True, 'message': 'Product removed.'})
    elif action == 'flag':
        product.status = 'hidden'
        msg = "Product flagged and hidden."
    else:
        return jsonify({'success': False, 'message': 'Invalid action.'}), 400
        
    log = AdminLog(admin_id=current_user.id, action=f"Moderated product ID {product_id}: {action}", target_table="products", target_id=product_id)
    db.session.add(log)
    db.session.commit()
    return jsonify({'success': True, 'message': msg})

@admin_bp.route('/api/market/csv-import', methods=['POST'])
def csv_import():
    if 'csv_file' not in request.files:
        flash("No file part in request.", "danger")
        return redirect(url_for('admin.market'))
        
    file = request.files['csv_file']
    if file.filename == '':
        flash("No file selected.", "danger")
        return redirect(url_for('admin.market'))
        
    if file and file.filename.endswith('.csv'):
        # Parse CSV
        try:
            stream = io.StringIO(file.stream.read().decode("UTF8"), newline=None)
            csv_reader = csv.DictReader(stream)
            
            import_count = 0
            for row in csv_reader:
                crop = row.get('crop_name', '').strip()
                state = row.get('state', '').strip()
                price_str = row.get('price_per_quintal', '').strip()
                source = row.get('source', 'CSV Import').strip()
                
                if not crop or not state or not price_str:
                    continue
                    
                price = float(price_str)
                
                mp = MarketPrice(
                    crop_name=crop,
                    state=state,
                    price_per_quintal=price,
                    price_date=date.today(),
                    source=source
                )
                db.session.add(mp)
                import_count += 1
                
            db.session.commit()
            log = AdminLog(admin_id=current_user.id, action=f"Bulk imported {import_count} market prices", target_table="market_prices")
            db.session.add(log)
            db.session.commit()
            
            flash(f"Successfully imported {import_count} market price records.", "success")
        except Exception as e:
            db.session.rollback()
            flash(f"Error parsing CSV: {str(e)}", "danger")
    else:
        flash("Invalid file format. Upload .csv files only.", "danger")
        
    return redirect(url_for('admin.market'))

import io

@admin_bp.route('/api/ml/retrain', methods=['POST'])
def retrain_model_api():
    """Triggers background retraining of RandomForestRegressor crop model."""
    def retrain_worker(app_context):
        with app_context:
            try:
                from ml.train_model import train_crop_model
                train_crop_model()
                print("ML Model background retraining complete!")
            except Exception as e:
                print(f"ML Model background retraining failed: {str(e)}")
                
    # Run in background thread
    threading.Thread(target=retrain_worker, args=(current_app._get_current_object().app_context(),)).start()
    
    # Log retraining action
    log = AdminLog(admin_id=current_user.id, action="Triggered ML model retraining", target_table="model_predictions")
    db.session.add(log)
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': 'Model retraining job triggered in background.'
    })

@admin_bp.route('/api/ml/download')
def download_model():
    """Download the trained .pkl model file."""
    ml_dir = os.path.join(current_app.root_path, 'ml')
    filename = 'crop_price_model.pkl'
    if os.path.exists(os.path.join(ml_dir, filename)):
        return send_from_directory(ml_dir, filename, as_attachment=True)
    else:
        return jsonify({'success': False, 'message': 'Model file not found.'}), 404

from functools import wraps
from flask import abort, current_app
from flask_login import current_user
import os

def role_required(*roles):
    """Decorator to restrict access to specific user roles."""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated or current_user.role not in roles:
                abort(403)  # Forbidden
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def farmer_required(f):
    return role_required('farmer')(f)

def buyer_required(f):
    return role_required('buyer')(f)

def admin_required(f):
    return role_required('admin')(f)

def allowed_file(filename):
    """Check if file extension is allowed."""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in current_app.config['ALLOWED_EXTENSIONS']

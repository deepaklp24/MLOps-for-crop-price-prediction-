import io
import csv
import random
from datetime import date, timedelta
from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify, Response
from flask_login import login_required, current_user
from models import db, MarketPrice
from routes.utils import admin_required

market_bp = Blueprint('market', __name__)

def get_crop_category(crop_name):
    # Mapping crops to categories
    grain_crops = {"Wheat", "Paddy", "Maize", "Barley", "Millet", "Sorghum"}
    pulse_crops = {"Chickpeas", "Pigeon Peas", "Mung Beans", "Black Gram", "Lentils", "Mustard", "Soybean", "Sunflower", "Cotton", "Jute", "Sugarcane", "Chili"}
    veg_crops = {"Potato", "Onion", "Tomato", "Garlic", "Ginger", "Cabbage", "Cauliflower", "Turmeric", "Coriander"}
    fruit_crops = {"Apple", "Mango", "Banana"}
    
    if crop_name in grain_crops:
        return "grains"
    elif crop_name in pulse_crops:
        return "pulses"
    elif crop_name in veg_crops:
        return "vegetables"
    elif crop_name in fruit_crops:
        return "fruits"
    return "grains"

@market_bp.route('/market-prices')
def market_prices():
    # Filters
    selected_state = request.args.get('state', 'all')
    selected_category = request.args.get('category', 'all')
    search_query = request.args.get('search', '').strip()
    
    # We want to display the latest price for each unique crop and state combination
    # In SQLite, we can fetch all records and do the group/filter in Python or write a query.
    # Python is simpler and less prone to SQLite syntax quirks for complex group by:
    all_prices = MarketPrice.query.order_by(MarketPrice.price_date.desc()).all()
    
    latest_records = {}
    previous_records = {}
    
    for r in all_prices:
        key = (r.crop_name, r.state)
        if key not in latest_records:
            latest_records[key] = r
        elif key not in previous_records:
            # This is the next most recent record
            previous_records[key] = r
            
    filtered_data = []
    
    for key, latest in latest_records.items():
        crop, state = key
        category = get_crop_category(crop)
        
        # Apply filters
        if selected_state != 'all' and state != selected_state:
            continue
        if selected_category != 'all' and category != selected_category:
            continue
        if search_query and search_query.lower() not in crop.lower():
            continue
            
        # Determine trend compared to the previous record
        prev = previous_records.get(key)
        if prev:
            if latest.price_per_quintal > prev.price_per_quintal:
                trend = 'up'
            elif latest.price_per_quintal < prev.price_per_quintal:
                trend = 'down'
            else:
                trend = 'flat'
        else:
            # Fallback random trend if only one record exists
            trend = 'flat'
            
        filtered_data.append({
            'id': latest.id,
            'crop_name': crop,
            'category': category,
            'state': state,
            'price_per_quintal': latest.price_per_quintal,
            'price_date': latest.price_date,
            'trend': trend,
            'source': latest.source
        })
        
    # Get list of unique states
    states_list = sorted(list({r.state for r in all_prices}))
    
    return render_template(
        'market_prices.html',
        prices=filtered_data,
        states=states_list,
        current_state=selected_state,
        current_category=selected_category,
        current_search=search_query
    )

# --- API ENDPOINTS ---
@market_bp.route('/api/market/prices')
def api_market_prices():
    # Return all prices JSON
    all_prices = MarketPrice.query.order_by(MarketPrice.price_date.desc()).all()
    data = []
    for p in all_prices:
        data.append({
            'crop_name': p.crop_name,
            'category': get_crop_category(p.crop_name),
            'state': p.state,
            'price_per_quintal': p.price_per_quintal,
            'price_date': p.price_date.strftime('%Y-%m-%d'),
            'source': p.source
        })
    return jsonify(data)

@market_bp.route('/api/market/prices/<string:crop>')
def api_market_price_history(crop):
    state = request.args.get('state')
    
    query = MarketPrice.query.filter_by(crop_name=crop)
    if state:
        query = query.filter_by(state=state)
        
    # Sort chronological
    history = query.order_by(MarketPrice.price_date.asc()).all()
    
    # Limit to last 30 entries
    history = history[-30:]
    
    data = []
    for h in history:
        data.append({
            'date': h.price_date.strftime('%d %b'),
            'price_per_kg': round(h.price_per_quintal / 100.0, 2), # per kg
            'price_per_quintal': h.price_per_quintal
        })
    return jsonify(data)

@market_bp.route('/api/market/prices/update')
def api_market_prices_update():
    """Generates minor random price variations on existing today's/latest data to simulate live feed."""
    latest_records = {}
    all_prices = MarketPrice.query.order_by(MarketPrice.price_date.desc()).all()
    
    for r in all_prices:
        key = (r.crop_name, r.state)
        if key not in latest_records:
            latest_records[key] = r
            
    # For each latest record, create a new record for today with slight variation
    new_records_count = 0
    for key, record in latest_records.items():
        # Add random variation between -3% and +3%
        variation = random.uniform(-0.03, 0.03)
        new_price = record.price_per_quintal * (1.0 + variation)
        
        # Avoid creating duplicate entry for same crop/state/date
        # Check if record already exists for today
        existing_today = MarketPrice.query.filter_by(
            crop_name=record.crop_name,
            state=record.state,
            price_date=date.today()
        ).first()
        
        if existing_today:
            # Update price
            existing_today.price_per_quintal = round(new_price, 2)
        else:
            # Create new row for today
            new_mp = MarketPrice(
                crop_name=record.crop_name,
                state=record.state,
                price_per_quintal=round(new_price, 2),
                price_date=date.today(),
                source="Simulated Real-Time Update"
            )
            db.session.add(new_mp)
            new_records_count += 1
            
    db.session.commit()
    return jsonify({
        'success': True,
        'message': f'Prices updated. Generated {new_records_count} new entries, updated others.'
    })

@market_bp.route('/api/market/prices/export')
def api_market_prices_export():
    """Exports latest market prices to CSV."""
    all_prices = MarketPrice.query.order_by(MarketPrice.price_date.desc()).all()
    
    latest_records = {}
    for r in all_prices:
        key = (r.crop_name, r.state)
        if key not in latest_records:
            latest_records[key] = r
            
    # Create CSV in-memory
    output = io.StringIO()
    writer = csv.writer(output)
    
    # Write header
    writer.writerow(['Crop Name', 'Category', 'State', 'Price per Quintal (INR)', 'Price per KG (INR)', 'Updated Date', 'Source'])
    
    for r in latest_records.values():
        category = get_crop_category(r.crop_name)
        price_kg = round(r.price_per_quintal / 100.0, 2)
        writer.writerow([r.crop_name, category, r.state, r.price_per_quintal, price_kg, r.price_date.strftime('%Y-%m-%d'), r.source])
        
    output.seek(0)
    
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-disposition": "attachment; filename=agriconnect_market_prices.csv"}
    )

@market_bp.route('/api/market/prices', methods=['POST'])
@login_required
@admin_required
def api_add_market_price():
    data = request.json or {}
    crop_name = data.get('crop_name')
    state = data.get('state')
    price_per_quintal = data.get('price_per_quintal')
    
    if not crop_name or not state or price_per_quintal is None:
        return jsonify({'success': False, 'message': 'Missing fields.'}), 400
        
    mp = MarketPrice(
        crop_name=crop_name,
        state=state,
        price_per_quintal=float(price_per_quintal),
        price_date=date.today(),
        source="Admin Manual Entry"
    )
    db.session.add(mp)
    db.session.commit()
    return jsonify({'success': True, 'message': 'Market price added.'})

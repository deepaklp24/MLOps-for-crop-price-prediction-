import os
from flask import Flask, redirect, url_for
from flask_login import LoginManager
from flask_wtf.csrf import CSRFProtect
from config import Config
from models import db, User

login_manager = LoginManager()
csrf = CSRFProtect()

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # Ensure folders exist
    os.makedirs(os.path.join(app.static_folder, 'uploads'), exist_ok=True)
    os.makedirs(os.path.join(app.root_path, 'database'), exist_ok=True)

    # Initialize extensions
    db.init_app(app)
    
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'
    login_manager.login_message_category = 'warning'
    
    csrf.init_app(app)

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    # Register Blueprints
    from routes.auth import auth_bp
    from routes.farmer import farmer_bp
    from routes.buyer import buyer_bp
    from routes.market import market_bp
    from routes.predict import predict_bp
    from routes.admin import admin_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(farmer_bp)
    app.register_blueprint(buyer_bp)
    app.register_blueprint(market_bp)
    app.register_blueprint(predict_bp)
    app.register_blueprint(admin_bp)

    # Root redirect
    @app.route('/')
    def root():
        return redirect(url_for('buyer.home'))

    return app

if __name__ == '__main__':
    app = create_app()
    # Create tables if database doesn't exist
    with app.app_context():
        db.create_all()
    app.run(debug=True, port=5000)

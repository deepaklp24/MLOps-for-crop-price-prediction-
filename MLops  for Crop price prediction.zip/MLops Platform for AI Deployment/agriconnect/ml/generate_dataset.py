import os
import random
import pandas as pd
import numpy as np

def generate_synthetic_data(num_rows=5000, output_path=None):
    np.random.seed(42)
    random.seed(42)

    # 30+ Crops with base price per quintal in INR
    crop_base_prices = {
        'Wheat': 2125, 'Paddy': 2183, 'Maize': 2090, 'Barley': 1735, 'Millet': 2350, 
        'Sorghum': 2970, 'Chickpeas': 5335, 'Pigeon Peas': 7000, 'Mung Beans': 8558, 
        'Black Gram': 6950, 'Lentils': 6000, 'Mustard': 5450, 'Groundnut': 6377, 
        'Soybean': 4600, 'Sunflower': 6760, 'Cotton': 6620, 'Jute': 5050, 
        'Sugarcane': 315, 'Potato': 1500, 'Onion': 1800, 'Tomato': 2200, 
        'Garlic': 8000, 'Ginger': 9500, 'Turmeric': 7500, 'Coriander': 6500, 
        'Chili': 12000, 'Cabbage': 1200, 'Cauliflower': 1400, 'Apple': 9000, 
        'Mango': 7000, 'Banana': 2500
    }
    crops = list(crop_base_prices.keys())

    # 20 States with multiplier factor
    state_multipliers = {
        'Uttar Pradesh': 0.95, 'Madhya Pradesh': 0.90, 'Punjab': 1.05, 'Haryana': 1.03, 
        'Rajasthan': 0.98, 'Bihar': 0.88, 'West Bengal': 0.96, 'Maharashtra': 1.02, 
        'Gujarat': 1.01, 'Andhra Pradesh': 0.99, 'Telangana': 0.98, 'Karnataka': 1.00, 
        'Tamil Nadu': 1.02, 'Kerala': 1.15, 'Odisha': 0.92, 'Chhattisgarh': 0.89, 
        'Jharkhand': 0.87, 'Assam': 0.94, 'Himachal Pradesh': 1.08, 'Jammu and Kashmir': 1.10
    }
    states = list(state_multipliers.keys())

    # Season mapping
    # 0 = Kharif (June - October), 1 = Rabi (November - April), 2 = Zaid (March - June)
    def get_season(month):
        if month in [6, 7, 8, 9, 10]:
            return 0  # Kharif
        elif month in [11, 12, 1, 2, 3, 4]:
            return 1  # Rabi
        else:
            return 2  # Zaid

    data = []
    for _ in range(num_rows):
        crop = random.choice(crops)
        state = random.choice(states)
        year = random.randint(2020, 2026)
        month = random.randint(1, 12)
        season = get_season(month)
        
        base_price = crop_base_prices[crop]
        state_mult = state_multipliers[state]
        
        # Random index metrics
        rainfall_index = random.uniform(0.1, 1.0)
        demand_score = random.uniform(0.1, 1.0)
        
        # Inflation trend (approx 4.5% per year from 2020 base)
        year_factor = 1.0 + (year - 2020) * 0.045
        
        # Season factor (slight variations)
        # e.g., prices go up right before harvest
        season_factors = {0: 1.02, 1: 0.98, 2: 1.05}
        season_fact = season_factors[season]
        
        # Rainfall and demand dynamics:
        # High demand -> higher price. Low rainfall -> lower supply -> higher price.
        market_dynamics = 1.0 + (0.12 * demand_score) - (0.08 * rainfall_index)
        
        # Calculate historical average price (rolling 3-month average mockup)
        hist_avg = base_price * state_mult * year_factor * season_fact
        
        # Final price with some random noise (std dev = 5% of base price)
        noise = np.random.normal(0, 0.05 * base_price)
        target_price = (hist_avg * market_dynamics) + noise
        
        # Enforce positive price
        target_price = max(base_price * 0.5, target_price)

        data.append({
            'crop_name': crop,
            'state': state,
            'month': month,
            'season': season,
            'year': year,
            'rainfall_index': round(rainfall_index, 2),
            'demand_score': round(demand_score, 2),
            'historical_avg_price': round(hist_avg, 2),
            'price_per_quintal': round(target_price, 2)
        })

    df = pd.DataFrame(data)
    
    if output_path:
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        df.to_csv(output_path, index=False)
        print(f"Dataset of {num_rows} rows saved to: {output_path}")
    
    return df

if __name__ == '__main__':
    script_dir = os.path.dirname(os.path.abspath(__file__))
    generate_synthetic_data(num_rows=5000, output_path=os.path.join(script_dir, 'crop_prices_synthetic.csv'))

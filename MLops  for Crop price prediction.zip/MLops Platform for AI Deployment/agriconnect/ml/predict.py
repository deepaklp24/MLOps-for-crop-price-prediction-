import os
import joblib
import numpy as np
import pandas as pd
from datetime import datetime

_model_artifacts = None

def load_model_artifacts():
    global _model_artifacts
    if _model_artifacts is None:
        ml_dir = os.path.dirname(os.path.abspath(__file__))
        model_path = os.path.join(ml_dir, 'crop_price_model.pkl')
        if not os.path.exists(model_path):
            raise FileNotFoundError(f"Model file not found at: {model_path}. Please train the model first.")
        _model_artifacts = joblib.load(model_path)
    return _model_artifacts

def predict_crop_price(crop_name, state, target_date_str, season=None, rainfall_index=0.6, demand_score=0.7, historical_avg_price=None):
    """
    Predicts the price per kg of a crop using the trained RandomForestRegressor model.
    Also calculates the confidence score based on tree predictions standard deviation.
    """
    artifacts = load_model_artifacts()
    model = artifacts['model']
    crop_encoder = artifacts['crop_encoder']
    state_encoder = artifacts['state_encoder']
    
    # 1. Parse target date
    try:
        target_date = datetime.strptime(target_date_str, "%Y-%m-%d")
    except ValueError:
        target_date = datetime.now()
        
    year = target_date.year
    month = target_date.month
    
    # 2. Determine season if not provided
    # 0 = Kharif, 1 = Rabi, 2 = Zaid
    if season is None:
        if month in [6, 7, 8, 9, 10]:
            season = 0
        elif month in [11, 12, 1, 2, 3, 4]:
            season = 1
        else:
            season = 2
            
    # 3. Label encode inputs
    try:
        crop_encoded = crop_encoder.transform([crop_name])[0]
    except ValueError:
        # Fallback for unseen crops
        crop_encoded = 0
        
    try:
        state_encoded = state_encoder.transform([state])[0]
    except ValueError:
        # Fallback for unseen states
        state_encoded = 0

    # 4. Determine or lookup historical average price if not provided
    # If not provided, we can estimate it based on average values in the training set or a constant.
    # We will use crop base prices as reference.
    crop_base_prices = {
        'Wheat': 2125, 'Paddy': 2183, 'Maize': 2090, 'Barley': 1735, 'Millet': 2350, 
        'Sorghum': 2970, 'Chickpeas': 5335, 'Pigeon Peas': 7000, 'Mung Beans': 8558, 
        'Black Gram': 6950, 'Lentils': 6000, 'Mustard': 5450, 'Groundnut': 6377, 
        'Soybean': 4600, 'Sunflower': 6760, 'Cotton': 6620, 'Jute': 5050, 
        'Sugarcane': 315, 'Potato': 1500, 'Onion': 1800, 'Tomato': 2200, 
        'Garlic': 8000, 'Ginger': 9500, 'Turmeric': 7500, 'Coriander': 6500, 
        'Chili': 12000, 'Cabbage': 1200, 'Cauliflower': 1400, 'Apple': 9000, 
        'Mango': 7000, 'Banana': 2500
    }
    
    if historical_avg_price is None:
        base = crop_base_prices.get(crop_name, 3000)
        # Apply slight inflation trend (4.5% per year)
        historical_avg_price = base * (1.0 + (year - 2020) * 0.045)
        
    # 5. Assemble feature vector
    features = pd.DataFrame([{
        'crop_name_encoded': crop_encoded,
        'state_encoded': state_encoded,
        'month': month,
        'season': season,
        'year': year,
        'rainfall_index': rainfall_index,
        'demand_score': demand_score,
        'historical_avg_price': historical_avg_price
    }])
    
    # Ensure features match correct order
    features = features[artifacts['feature_cols']]
    
    # 6. Predict using all trees to calculate standard deviation
    # shape: (n_estimators, n_samples)
    tree_preds = np.array([estimator.predict(features.values)[0] for estimator in model.estimators_])
    
    mean_prediction_quintal = np.mean(tree_preds)
    std_prediction_quintal = np.std(tree_preds)
    
    # Calculate confidence score: 1 - (std_dev / mean)
    if mean_prediction_quintal > 0:
        confidence = 1.0 - (std_prediction_quintal / mean_prediction_quintal)
    else:
        confidence = 0.0
        
    # Cap confidence between 0.0 and 1.0 (expressed as percentage, e.g. 0-100)
    confidence = max(0.1, min(0.99, confidence))
    confidence_percentage = round(confidence * 100, 2)
    
    # Convert prices from Quintal to kg (1 quintal = 100 kg)
    predicted_price_kg = mean_prediction_quintal / 100.0
    
    # Define Min/Max band based on tree predictions (1.96 * std_dev)
    margin = (1.96 * std_prediction_quintal) / 100.0
    min_price = max(predicted_price_kg * 0.7, predicted_price_kg - margin)
    max_price = predicted_price_kg + margin
    
    # Recommendation logic
    # High demand & high confidence -> Good time to sell. Low demand -> Wait.
    if demand_score > 0.75:
        recommendation = "High demand. Good time to sell!"
    elif demand_score < 0.45:
        recommendation = "Price may drop — sell now."
    else:
        recommendation = "Prices are stable. Wait 2 weeks for peak harvest."
        
    return {
        'predicted_price_kg': round(predicted_price_kg, 2),
        'confidence_score': confidence_percentage,
        'min_price_kg': round(min_price, 2),
        'max_price_kg': round(max_price, 2),
        'recommendation': recommendation,
        'model_version': artifacts.get('metrics', {}).get('version', '1.0.0'),
        'target_date': target_date_str
    }

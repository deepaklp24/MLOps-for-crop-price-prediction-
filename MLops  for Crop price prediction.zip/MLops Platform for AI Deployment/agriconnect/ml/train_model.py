import os
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import joblib

# Ensure the generate_dataset script can be imported
from generate_dataset import generate_synthetic_data

def train_crop_model():
    ml_dir = os.path.dirname(os.path.abspath(__file__))
    csv_path = os.path.join(ml_dir, 'crop_prices_synthetic.csv')
    
    if not os.path.exists(csv_path):
        print("Dataset not found. Generating synthetic dataset...")
        df = generate_synthetic_data(num_rows=5000, output_path=csv_path)
    else:
        df = pd.read_csv(csv_path)
        
    print("Pre-processing dataset...")
    
    # We will use LabelEncoder for crop_name and state
    crop_encoder = LabelEncoder()
    state_encoder = LabelEncoder()
    
    df['crop_name_encoded'] = crop_encoder.fit_transform(df['crop_name'])
    df['state_encoded'] = state_encoder.fit_transform(df['state'])
    
    # Feature columns
    feature_cols = [
        'crop_name_encoded', 'state_encoded', 'month', 'season', 
        'year', 'rainfall_index', 'demand_score', 'historical_avg_price'
    ]
    target_col = 'price_per_quintal'
    
    X = df[feature_cols]
    y = df[target_col]
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    print(f"Training RandomForestRegressor model (n_estimators=200, max_depth=15)...")
    model = RandomForestRegressor(n_estimators=200, max_depth=15, random_state=42, n_jobs=-1)
    model.fit(X_train, y_train)
    
    # Evaluate model
    y_pred = model.predict(X_test)
    r2 = r2_score(y_test, y_pred)
    mae = mean_absolute_error(y_test, y_pred)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    
    print("\nModel Evaluation Metrics:")
    print(f"R² Score:  {r2:.4f}")
    print(f"MAE:       INR {mae:.2f} per quintal")
    print(f"RMSE:      INR {rmse:.2f} per quintal")
    
    # Save the artifacts: model, encoders, and performance stats
    model_artifacts = {
        'model': model,
        'crop_encoder': crop_encoder,
        'state_encoder': state_encoder,
        'feature_cols': feature_cols,
        'metrics': {
            'r2': float(r2),
            'mae': float(mae),
            'rmse': float(rmse),
            'num_samples': len(df)
        }
    }
    
    model_path = os.path.join(ml_dir, 'crop_price_model.pkl')
    joblib.dump(model_artifacts, model_path)
    print(f"\nModel artifacts saved successfully to: {model_path}")
    
    return model_artifacts

if __name__ == '__main__':
    train_crop_model()
